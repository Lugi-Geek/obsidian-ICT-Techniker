"""
Obsidian-Agent – Sprachen
=========================
Deutsch ist die Master-Sprache: Jeder Schlüssel muss in de.py stehen. Fehlt ein Schlüssel in
einer anderen Sprache, wird der deutsche Text verwendet.
Eine neue Sprache: de.py kopieren, übersetzen und unten in REIHENFOLGE eintragen.
"""
from __future__ import annotations

import importlib

STANDARD = "de"
REIHENFOLGE = ["de", "en", "fr", "it", "es", "ro"]
_CACHE: dict[str, dict] = {}


def hole(code: str | None) -> dict:
    code = (code or STANDARD).lower()[:2]
    if code not in REIHENFOLGE:
        code = STANDARD
    if code not in _CACHE:
        _CACHE[code] = importlib.import_module(f"sprachen.{code}").SPRACHE
    return _CACHE[code]


def liste() -> list[tuple[str, str]]:
    return [(c, hole(c)["name"]) for c in REIHENFOLGE]


def text(code: str | None, schluessel: str, **werte) -> str:
    s = hole(code)["t"].get(schluessel)
    if s is None:
        s = hole(STANDARD)["t"].get(schluessel, schluessel)
    if werte:
        try:
            return s.format(**werte)
        except (KeyError, IndexError, ValueError):
            return s
    return s
