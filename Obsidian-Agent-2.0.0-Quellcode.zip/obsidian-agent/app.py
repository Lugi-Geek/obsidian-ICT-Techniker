"""
Obsidian-Agent – Weboberfläche (nur lokal)
Start:  python app.py   ->  http://127.0.0.1:5055
"""
from __future__ import annotations

import datetime as dt
import os
import sys
import threading
import webbrowser
from pathlib import Path

BASE = Path(__file__).resolve().parent
for p in (BASE / "vendor", BASE):  # mitgelieferte Bibliotheken (Flask) – keine Installation nötig
    if p.is_dir() and str(p) not in sys.path:
        sys.path.insert(0, str(p))

from flask import Flask, flash, jsonify, redirect, render_template, request, url_for  # noqa: E402

import agent as core  # noqa: E402
import sprachen  # noqa: E402

app = Flask(__name__)
app.secret_key = "obsidian-agent-lokal"
AGENT = core.Agent()


def t(schluessel: str, **werte) -> str:
    return AGENT.t(schluessel, **werte)


@app.template_filter("dmy")
def _dmy(v):
    return AGENT.dmy(v)


@app.context_processor
def _globals():
    return {"heute": dt.date.today(), "cfg": AGENT.cfg, "vault_ok": AGENT.vault_ok(),
            "letzter_sync": AGENT.letzter_sync(), "PRIO": core.STUFEN, "t": t, "L": AGENT.L,
            "SPRACHEN": sprachen.liste(), "VERSION": core.VERSION,
            "TEAM_NAMEN": [p["titel"] for p in AGENT.eintraege("person")] if AGENT.vault_ok() else []}


@app.before_request
def _vault_pruefen():
    if request.endpoint in ("einstellungen", "static", "sprache") or AGENT.vault_ok():
        return None
    flash(t("m_vault_setzen", pfad=str(AGENT.vault)), "fehler")
    return redirect(url_for("einstellungen"))


def _ok(msg):
    flash(msg, "ok")


def _fehler(exc):
    flash(AGENT.meldung(exc), "fehler")


def _zurueck(standard: str):
    return redirect(request.referrer or url_for(standard))


# --- Heute ---------------------------------------------------------------------
@app.route("/")
def dashboard():
    g = AGENT.tasks()
    n = int(AGENT.cfg.get("demnaechst_tage", 7))
    grenze = dt.date.today() + dt.timedelta(days=n)
    bald = [x for x in g["geplant"] if core.parse_date(x["start"]) <= grenze]
    return render_template("dashboard.html", g=g, bald=bald,
                           notizen=AGENT.letzte_notizen(8), projekte=AGENT.projekte())


@app.post("/sync")
def sync():
    try:
        s = AGENT.sync("manuell")
        _ok(t("m_sync_ok", dateien=s["dateien"], heute=s["tasks_heute"], offen=s["tasks_offen"], ms=s["dauer_ms"]))
    except Exception as exc:
        _fehler(exc)
    return _zurueck("dashboard")


# --- Tasks ---------------------------------------------------------------------
@app.route("/tasks")
def tasks():
    projekt = request.args.get("projekt", "")
    return render_template("tasks.html", g=AGENT.tasks(projekt=projekt), projekt=projekt,
                           projekte=AGENT.projekte(), status_liste=core.TASK_STATUS)


@app.post("/tasks/neu")
def task_neu():
    f = request.form
    try:
        p = AGENT.task_anlegen(f["titel"], f.get("start", ""), f.get("ende", ""), f.get("projekt", ""),
                               f.get("prioritaet", "mittel"), f.get("verantwortlich", ""),
                               f.get("beschreibung", ""), f.get("checkliste", ""),
                               unterordner=f.get("unterordner", ""))
        _ok(t("m_task_angelegt", pfad=AGENT.rel(p)))
    except Exception as exc:
        _fehler(exc)
    return _zurueck("tasks")


@app.get("/api/projektordner")
def projekt_ordner_api():
    """Unterordner eines Projekts für die Ordnerauswahl (live aus dem Vault)."""
    projekt = request.args.get("projekt", "")
    return jsonify({"ordner": AGENT.projekt_unterordner(projekt),
                    "standard": (AGENT.cfg.get("task_standard_ordner") or "").strip("/")})


@app.post("/tasks/status")
def task_status():
    try:
        AGENT.task_status_setzen(request.form["pfad"], request.form["status"])
    except Exception as exc:
        _fehler(exc)
    return _zurueck("tasks")


@app.post("/tasks/verschieben")
def task_verschieben():
    try:
        AGENT.task_verschieben(request.form["pfad"], int(request.form.get("tage", 1)))
    except Exception as exc:
        _fehler(exc)
    return _zurueck("tasks")


# --- Projekte ------------------------------------------------------------------
@app.route("/projekte")
def projekte():
    return render_template("projekte.html", projekte=AGENT.projekte(), struktur=AGENT.projekt_struktur())


@app.post("/projekte/neu")
def projekt_neu():
    f = request.form
    try:
        p = AGENT.projekt_anlegen(f["name"], f.get("kunde", ""), f.get("beschreibung", ""),
                                  f.get("projektleitung", ""), f.get("ende", ""))
        _ok(t("m_projekt_angelegt", pfad=AGENT.rel(p), n=len(AGENT.projekt_struktur())))
    except Exception as exc:
        _fehler(exc)
    return redirect(url_for("projekte"))


@app.post("/projekte/ergaenzen")
def projekte_ergaenzen():
    try:
        n_proj, n_ord = AGENT.projekte_ergaenzen()
        _ok(t("m_projekte_ergaenzt", projekte=n_proj, ordner=n_ord))
    except Exception as exc:
        _fehler(exc)
    return redirect(url_for("projekte"))


# --- Dokumentation ---------------------------------------------------------------
@app.route("/notizen")
def notizen():
    return render_template("notizen.html", typen=AGENT.notiz_typen(), projekte=AGENT.projekte(),
                           projekt=request.args.get("projekt", ""), notizen=AGENT.letzte_notizen(30))


@app.post("/notizen/neu")
def notiz_neu():
    f = request.form
    try:
        p = AGENT.notiz_anlegen(f["typ"], f["titel"], f.get("projekt", ""))
        _ok(t("m_notiz_angelegt", pfad=AGENT.rel(p)))
    except Exception as exc:
        _fehler(exc)
    return redirect(url_for("notizen", projekt=f.get("projekt", "")))


# --- Aus Vorlage -------------------------------------------------------------------
@app.route("/vorlage")
def vorlage():
    return render_template("vorlage.html", vorlagen=AGENT.vorlagen_liste(), projekte=AGENT.projekte(),
                           projekt=request.args.get("projekt", ""), gewaehlt=request.args.get("vorlage", ""),
                           notizen=AGENT.letzte_notizen(12))


@app.post("/vorlage/neu")
def vorlage_neu():
    f = request.form
    try:
        p = AGENT.aus_vorlage_anlegen(f.get("vorlage", ""), f.get("titel", ""), f.get("projekt", ""),
                                      f.get("unterordner", ""))
        _ok(t("m_notiz_angelegt", pfad=AGENT.rel(p)))
        return redirect(url_for("vorlage", projekt=f.get("projekt", ""), vorlage=f.get("vorlage", "")))
    except Exception as exc:
        _fehler(exc)
    return _zurueck("vorlage")


# --- Jour Fixe ---------------------------------------------------------------------
@app.route("/jourfixe")
def jourfixe():
    serie = request.args.get("serie", "")
    erledigte = request.args.get("erledigte") == "1"
    return render_template("jourfixe.html", serie=serie, erledigte=erledigte,
                           serien=AGENT.jf_serien(), pendenzen=AGENT.jf_pendenzen(serie, alle=erledigte),
                           sitzungen=AGENT.jf_sitzungen(serie)[:15], projekte=AGENT.projekte(),
                           turnus=list(core.JF_TURNUS))


@app.post("/jourfixe/sitzung")
def jf_sitzung_neu():
    f = request.form.to_dict()
    if f.get("serie") == "__neu__":
        f["serie"] = f.get("serie_neu", "")
    try:
        p = AGENT.jf_sitzung_anlegen(f)
        _ok(t("m_sitzung_angelegt", pfad=AGENT.rel(p)))
        return redirect(url_for("jourfixe", serie=core.safe_name(f["serie"])))
    except Exception as exc:
        _fehler(exc)
    return _zurueck("jourfixe")


@app.post("/jourfixe/pendenz")
def jf_pendenz_neu():
    try:
        p = AGENT.jf_pendenz_anlegen(request.form.to_dict())
        _ok(t("m_pendenz_angelegt", pfad=AGENT.rel(p)))
    except Exception as exc:
        _fehler(exc)
    return _zurueck("jourfixe")


# --- Team ----------------------------------------------------------------------------
@app.route("/team")
def team():
    return render_template("team.html", team=AGENT.team())


@app.post("/team/neu")
def person_neu():
    try:
        _ok(t("m_person_angelegt", pfad=AGENT.rel(AGENT.person_anlegen(request.form.to_dict()))))
    except Exception as exc:
        _fehler(exc)
    return redirect(url_for("team"))


# --- Suche -------------------------------------------------------------------------
@app.route("/suche")
def suche():
    q = request.args.get("q", "").strip()
    return render_template("suche.html", q=q, treffer=AGENT.suche(q) if q else None)


# --- Einstellungen -----------------------------------------------------------------
FELDER = ["vault_path", "projekt_ordner", "task_ordner", "notiz_ordner", "vorlagen_ordner",
          "planer_ordner", "team_ordner", "jourfixe_ordner", "task_standard_ordner", "sync_zeit",
          "demnaechst_tage"]


@app.post("/sprache")
def sprache():
    code = request.form.get("sprache", "")
    try:
        ordner_neu = AGENT.sprache_setzen(code)
        _ok(t("m_sprache_ordner" if ordner_neu else "m_sprache_gesetzt"))
    except Exception as exc:
        _fehler(exc)
    return _zurueck("einstellungen")


@app.route("/einstellungen", methods=["GET", "POST"])
def einstellungen():
    if request.method == "POST":
        for k in FELDER:
            if k in request.form:
                v = request.form[k].strip()
                AGENT.cfg[k] = int(v) if k.endswith("_tage") and v.isdigit() else v
        core.save_config(AGENT.cfg)
        if AGENT.vault_ok():
            try:
                AGENT.sync("manuell")
                _ok(t("m_einstellungen_ok"))
            except Exception as exc:
                _fehler(exc)
        else:
            flash(t("m_einstellungen_vault_fehlt", pfad=str(AGENT.vault)), "fehler")
        return redirect(url_for("einstellungen"))
    return render_template("einstellungen.html", felder=FELDER, log=AGENT.sync_log(15),
                           db=AGENT.db_path, config=core.CONFIG_FILE, faellig=AGENT.geplanter_sync_faellig())


if __name__ == "__main__":
    port = int(AGENT.cfg.get("port", 5055))
    AGENT.starte_scheduler()
    if not os.environ.get("OBSIDIAN_AGENT_NO_BROWSER"):  # z.B. beim Autostart
        threading.Timer(1.2, lambda: webbrowser.open(f"http://127.0.0.1:{port}")).start()
    print(f"Obsidian-Agent: http://127.0.0.1:{port}  (Ctrl+C)")
    app.run(host="127.0.0.1", port=port, debug=False)
