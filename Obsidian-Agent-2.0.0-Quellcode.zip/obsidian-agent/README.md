# Obsidian-Agent 2.0

Lokale Weboberfläche für das Projektmanagement in Obsidian · Local web interface for project management in Obsidian

| Sprache / Language | Anleitung / Guide |
|---|---|
| Deutsch | [Anleitung/Anleitung_DE.md](Anleitung/Anleitung_DE.md) |
| English | [Anleitung/Guide_EN.md](Anleitung/Guide_EN.md) |
| Français | [Anleitung/Guide_FR.md](Anleitung/Guide_FR.md) |
| Italiano | [Anleitung/Guida_IT.md](Anleitung/Guida_IT.md) |
| Español | [Anleitung/Guia_ES.md](Anleitung/Guia_ES.md) |
| Română | [Anleitung/Ghid_RO.md](Anleitung/Ghid_RO.md) |

**Installation:** Windows `Obsidian-Agent-Setup-2.0.0.exe` · macOS `Obsidian-Agent-2.0.0.pkg` · ohne Installation / without installation: `start.bat` bzw. `start.sh` (Python 3.9+).

## Aufbau

| Datei / Ordner | Inhalt |
|---|---|
| `agent.py` | Kernlogik und Kommandozeile (nur Python-Standardbibliothek) |
| `app.py` | Weboberfläche (Flask), nur erreichbar unter `127.0.0.1` |
| `vorlagen.py` | Notizvorlagen, aus den Sprachdateien aufgebaut |
| `sprachen/` | `de.py` (Master), `en.py`, `fr.py`, `it.py`, `es.py`, `ro.py` |
| `templates/`, `static/` | Seiten und Stil der Oberfläche |
| `vendor/` | mitgelieferte Bibliotheken (Flask und Abhängigkeiten, BSD-Lizenzen) |
| `starter.pyw`, `hintergrund.pyw` | Öffnen bzw. Hintergrundstart (Startmenü, Autostart, macOS-App) |
| `setup/` | Einrichtung und Deinstallation für Windows (PowerShell), Symbole |
| `Anleitung/` | Anleitungen in sechs Sprachen |

Neue Sprache: `sprachen/de.py` kopieren, übersetzen und in `sprachen/__init__.py` unter `REIHENFOLGE` eintragen.
