@echo off
REM Obsidian-Agent ohne Installation starten (Windows, Python 3.9+ noetig).
cd /d "%~dp0"
where py >nul 2>&1 && (py -3 app.py) || (python app.py)
pause
