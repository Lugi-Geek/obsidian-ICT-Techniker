"""
Obsidian-Agent öffnen: Läuft der Agent schon, wird nur der Browser geöffnet.
Sonst wird er im Hintergrund gestartet. (Startmenü, Desktop-Verknüpfung, macOS-App)
"""
import socket
import subprocess
import sys
import time
import webbrowser
from pathlib import Path

BASE = Path(__file__).resolve().parent
sys.path[:0] = [str(BASE / "vendor"), str(BASE)]
import agent  # noqa: E402

PORT = int(agent.load_config().get("port", 5055))


def laeuft() -> bool:
    try:
        socket.create_connection(("127.0.0.1", PORT), timeout=0.5).close()
        return True
    except OSError:
        return False


if not laeuft():
    flags = 0x00000008 | 0x00000200 if sys.platform == "win32" else 0  # DETACHED_PROCESS | NEW_PROCESS_GROUP
    subprocess.Popen([sys.executable, str(BASE / "hintergrund.pyw")], cwd=str(BASE), creationflags=flags,
                     close_fds=True, start_new_session=sys.platform != "win32")
    for _ in range(60):
        if laeuft():
            break
        time.sleep(0.25)
webbrowser.open(f"http://127.0.0.1:{PORT}")
