"""
Obsidian-Agent – Notizvorlagen
==============================
Baut die Markdown-Vorlagen in der eingestellten Sprache. Beim ersten Start werden sie nach
<Vault>/<Vorlagen-Ordner>/ geschrieben und können danach in Obsidian frei angepasst werden.

Die Frontmatter-Schlüssel (typ, titel, projekt, start, ende, status, prioritaet, verantwortlich …)
sind in allen Sprachen gleich, damit der Agent jeden Vault lesen kann. Übersetzt werden
Überschriften, Hilfetexte, Dateinamen und Ordnernamen.
Platzhalter: {{title}}, {{date}}, {{projekt}} (kompatibel mit dem Obsidian-Kern-Plugin "Vorlagen").
"""
from __future__ import annotations

from functools import lru_cache


def _task(t):
    return f"""---
typ: task
titel: {{{{title}}}}
projekt: {{{{projekt}}}}
start: {{{{start}}}}
ende: {{{{ende}}}}
status: offen
prioritaet: {{{{prioritaet}}}}
verantwortlich: {{{{verantwortlich}}}}
erstellt: {{{{date}}}}
tags: [task]
---
# {{{{title}}}}

## {t['v_beschreibung']}
{{{{beschreibung}}}}

## {t['v_checkliste']}
{{{{checkliste}}}}

## {t['v_notizen']}
"""


def _meeting(t):
    return f"""---
typ: meeting
titel: {{{{title}}}}
projekt: {{{{projekt}}}}
datum: {{{{date}}}}
teilnehmende:
tags: [meeting]
---
# {t['v_protokoll']}: {{{{title}}}}
**{t['v_datum']}:** {{{{date}}}}  **{t['v_projekt']}:** {{{{projekt}}}}

## {t['v_teilnehmende']}
-

## {t['v_traktanden']}
1.

## {t['v_ergebnisse']}
-

## {t['v_entscheidungen']}
-

## {t['v_aktionspunkte']}
> {t['v_tipp_aktion']}

| {t['v_was']} | {t['v_wer']} | {t['v_bis']} |
|-----|-----|-----|
|     |     |     |
"""


def _entscheidung(t):
    return f"""---
typ: entscheidung
titel: {{{{title}}}}
projekt: {{{{projekt}}}}
datum: {{{{date}}}}
status: vorgeschlagen
tags: [entscheidung]
---
# {t['v_entscheidung']}: {{{{title}}}}

## {t['v_kontext']}
{t['v_kontext_hilfe']}

## {t['v_optionen']}
1.
2.

## {t['v_beschluss']}

## {t['v_begruendung']}

## {t['v_konsequenzen']}
"""


def _risiko(t):
    return f"""---
typ: risiko
titel: {{{{title}}}}
projekt: {{{{projekt}}}}
datum: {{{{date}}}}
wahrscheinlichkeit: mittel
auswirkung: mittel
status: offen
verantwortlich:
tags: [risiko]
---
# {t['v_risiko']}: {{{{title}}}}

## {t['v_beschreibung']}

## {t['v_ursachen']}

## {t['v_folgen']}

## {t['v_bewertung']}
| {t['v_wahrscheinlichkeit']} | {t['v_auswirkung']} | {t['v_einstufung']} |
|-----|-----|-----|
|     |     |     |

## {t['v_massnahmen']}
- [ ]

## {t['v_verlauf']}
- {{{{date}}}} – {t['v_erfasst']}
"""


def _change(t):
    return f"""---
typ: change
titel: {{{{title}}}}
projekt: {{{{projekt}}}}
datum: {{{{date}}}}
status: beantragt
prioritaet: mittel
tags: [change]
---
# {t['v_change']}: {{{{title}}}}

## {t['v_beschreibung']}

## {t['v_begruendung']}

## {t['v_auswirkungen']}
| {t['v_bereich']} | {t['v_auswirkung']} |
|-----|-----|
| {t['v_termine']} | |
| {t['v_kosten']} | |
| {t['v_umfang']} | |

## {t['v_entscheid']}

## {t['v_umsetzung']}
"""


def _kontakt(t):
    return f"""---
typ: kontakt
titel: {{{{title}}}}
projekt: {{{{projekt}}}}
firma:
rolle:
telefon:
email:
einfluss:
tags: [kontakt]
---
# {{{{title}}}}

| {t['v_feld']} | {t['v_wert']} |
|------|------|
| {t['v_firma']} | |
| {t['v_rolle']} | |
| {t['v_telefon']} | |
| {t['v_email']} | |
| {t['v_einfluss']} | |

## {t['v_erwartungen']}

## {t['v_notizen']}
"""


def _report(t):
    return f"""---
typ: report
titel: {{{{title}}}}
projekt: {{{{projekt}}}}
periode:
erstellt: {{{{date}}}}
ampel: gruen
tags: [report]
---
# {t['v_report']}: {{{{title}}}}

## {t['v_zusammenfassung']}

## {t['v_status']}
| {t['v_bereich']} | {t['v_ampel']} | {t['v_kommentar']} |
|-----|-----|-----|
| {t['v_termine']} | | |
| {t['v_kosten']} | | |
| {t['v_umfang']} | | |
| {t['v_qualitaet']} | | |

## {t['v_erreicht']}

## {t['v_naechste_schritte']}

## {t['v_risiken_probleme']}
"""


def _abschluss(t):
    return f"""---
typ: abschluss
titel: {{{{title}}}}
projekt: {{{{projekt}}}}
datum: {{{{date}}}}
tags: [abschluss]
---
# {t['v_abschluss']}: {{{{title}}}}

## {t['v_zielerreichung']}

## {t['v_offene_punkte']}
- [ ]

## {t['v_lessons']}
-

## {t['v_uebergabe']}

## {t['v_abnahme']}
| {t['v_rolle']} | {t['v_name']} | {t['v_datum']} |
|-----|-----|-----|
|     |     |     |
"""


def _person(t):
    return f"""---
typ: person
titel: {{{{title}}}}
kuerzel: {{{{kuerzel}}}}
rolle: {{{{rolle}}}}
team: {{{{team}}}}
email: {{{{email}}}}
telefon: {{{{telefon}}}}
standort: {{{{standort}}}}
vertretung: {{{{vertretung}}}}
skills: {{{{skills}}}}
tags: [team]
---
# {{{{title}}}}

| {t['v_feld']} | {t['v_wert']} |
|------|------|
| {t['v_rolle']} | {{{{rolle}}}} |
| {t['v_team']} | {{{{team}}}} |
| {t['v_email']} | {{{{email}}}} |
| {t['v_telefon']} | {{{{telefon}}}} |
| {t['v_standort']} | {{{{standort}}}} |
| {t['v_vertretung']} | {{{{vertretung}}}} |

## {t['v_aufgaben']}
-

## {t['v_skills']}
{{{{skills}}}}

## {t['v_abwesenheiten']}
| {t['v_von']} | {t['v_bis']} | {t['v_grund']} |
|-----|-----|-------|
|     |     |       |

## {t['v_notizen']}
"""


def _jourfixe(t):
    return f"""---
typ: jourfixe
titel: {{{{title}}}}
serie: {{{{serie}}}}
datum: {{{{datum}}}}
projekt: {{{{projekt}}}}
moderation: {{{{moderation}}}}
teilnehmer: {{{{teilnehmer}}}}
naechster_termin: {{{{naechster_termin}}}}
tags: [jourfixe]
---
# {{{{title}}}}

**{t['v_datum']}:** {{{{datum}}}} · **{t['v_moderation']}:** {{{{moderation}}}} · **{t['v_naechster_termin']}:** {{{{naechster_termin}}}}
**{t['v_teilnehmende']}:** {{{{teilnehmer}}}}

## {t['v_traktanden']}
{{{{agenda}}}}

## {t['v_offene_pendenzen']}
{{{{pendenzen}}}}

## {t['v_diskussion']}
-

## {t['v_beschluesse']}
-

## {t['v_neue_pendenzen']}
> {t['v_tipp_pendenz']}
"""


BAUER = {"task": _task, "meeting": _meeting, "entscheidung": _entscheidung, "risiko": _risiko,
         "change": _change, "kontakt": _kontakt, "report": _report, "abschluss": _abschluss,
         "person": _person, "jourfixe": _jourfixe}


@lru_cache(maxsize=None)
def _bauen(code: str) -> dict:
    import sprachen
    L = sprachen.hole(code)
    t = L["t"]
    out = {}
    for typ, f in BAUER.items():
        v = L["vorlagen"][typ]
        out[typ] = {"label": v["label"], "datei": v["datei"], "dateiname": v["dateiname"], "text": f(t)}
    return out


def bauen(L: dict) -> dict:
    return _bauen(L["code"])
