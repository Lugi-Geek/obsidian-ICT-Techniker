"""
Obsidian-Agent – Kernlogik
==========================
Verwaltet einen Obsidian-Vault für das Projektmanagement. Die Markdown-Dateien
bleiben die einzige Wahrheit; eine lokale SQLite-Datenbank dient als Index und Planer:

  * Projekte mit fester Ordnerstruktur anlegen
  * Task_*.md Dateien einlesen -> Tagesübersicht (heute / überfällig / demnächst)
  * Projektdokumente aus Vorlagen (Protokoll, Entscheidung, Risiko, Change, Stakeholder,
    Statusbericht, Projektabschluss), Jour Fixe mit Pendenzen, Teammitglieder
  * Volltextsuche über den ganzen Vault
  * Täglicher Sync (Standard 04:00)
  * Oberfläche, Vorlagen und Ordnernamen in DE / EN / FR / IT / ES / RO

CLI:
  python agent.py sync               # Vault einlesen, Tagesübersicht schreiben
  python agent.py sync --geplant     # wie oben, zählt als geplanter Tageslauf
  python agent.py heute              # heutige Tasks in der Konsole anzeigen
  python agent.py projekt "Name"     # neues Projekt anlegen
  python agent.py einrichten --sprache en --vault "C:\\Pfad\\zum\\Vault"
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import re
import sqlite3
import sys
import threading
import time
import urllib.parse
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

import sprachen  # noqa: E402
import vorlagen as vorlagen_mod  # noqa: E402

VERSION = "2.0.0"


def daten_dir() -> Path:
    """Ablage für config.json und planer.db.
    Portable (ZIP): Programmordner. Installiert (.exe / .pkg, Markierung '.paket'):
    Benutzerordner, damit das Programm selbst schreibgeschützt bleiben kann."""
    env = os.environ.get("OBSIDIAN_AGENT_DATA")
    if env:
        return Path(env).expanduser()
    if (BASE_DIR / ".paket").exists():
        if sys.platform == "darwin":
            return Path.home() / "Library" / "Application Support" / "Obsidian-Agent"
        if os.name == "nt":
            return Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "Obsidian-Agent"
        return Path(os.environ.get("XDG_CONFIG_HOME", str(Path.home() / ".config"))) / "obsidian-agent"
    return BASE_DIR


DATA_DIR = daten_dir()
CONFIG_FILE = DATA_DIR / "config.json"

OPTIONAL = ("obsidian_vault_name",)  # nicht im Standard enthalten, aber erlaubt
ORDNER_KEYS = ("projekt_ordner", "task_ordner", "notiz_ordner", "vorlagen_ordner",
               "planer_ordner", "team_ordner", "jourfixe_ordner")

TASK_STATUS = ["offen", "in_arbeit", "wartend", "erledigt"]
ERLEDIGT_WERTE = {"erledigt", "done", "abgeschlossen", "fertig", "x", "true", "ja", "closed",
                  "termine", "terminé", "completato", "completado", "finalizat"}
PRIO_ORDER = {"hoch": 0, "mittel": 1, "niedrig": 2}
STUFEN = ["hoch", "mittel", "niedrig"]
JF_TURNUS = {"woechentlich": 7, "2wochen": 14, "4wochen": 28, "monatlich": 0}

# Dokumenttypen unter "Dokumentation" und die Rolle des Projektordners, in dem sie landen
NOTIZ_TYPEN = ["meeting", "entscheidung", "risiko", "change", "kontakt", "report", "abschluss"]
TYP_ROLLE = {"meeting": "protokolle", "entscheidung": "planung", "risiko": "risiken",
             "change": "risiken", "kontakt": "stakeholder", "report": "reporting",
             "abschluss": "abschluss", "jourfixe": "protokolle", "task": ""}


def standard_config(sprache: str = sprachen.STANDARD) -> dict:
    L = sprachen.hole(sprache)
    cfg = {
        "sprache": L["code"],
        "vault_path": str(Path.home() / "Documents" / "Obsidian"),
        "db_path": "planer.db",            # relativ zum Datenordner oder absolut
        **L["ordner"],
        "task_standard_ordner": "",        # vorgewählter Unterordner für Tasks im Projekt
        "sync_zeit": "04:00",
        "demnaechst_tage": 7,
        "port": 5055,
        "projekt_praefix": L["projekt_praefix"],
        "projekt_struktur": [dict(s) for s in L["struktur"]],
    }
    return cfg


def load_config(sprache: str | None = None) -> dict:
    datei = {}
    if CONFIG_FILE.exists():
        try:
            datei = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            datei = {}
    # Konfigurationen aus Version 1 enthalten keine Sprache: dann Deutsch
    cfg = standard_config(datei.get("sprache") or sprache or sprachen.STANDARD)
    if datei and "projekt_praefix" not in datei:
        datei["projekt_praefix"] = "_Projekt_"
    cfg.update({k: v for k, v in datei.items() if k in cfg or k in OPTIONAL})
    if not CONFIG_FILE.exists():
        save_config(cfg)
    return cfg


def save_config(cfg: dict) -> None:
    CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(cfg, indent=2, ensure_ascii=False), encoding="utf-8")


# ---------------------------------------------------------------------------
# Hilfsfunktionen
# ---------------------------------------------------------------------------
FM_RE = re.compile(r"\A---[ \t]*\r?\n(.*?)^---[ \t]*(?:\r?\n|\Z)", re.S | re.M)
CHECK_RE = re.compile(r"^\s*[-*+] \[([ xX])\]", re.M)


def safe_name(name: str, underscore: bool = False) -> str:
    name = re.sub(r'[\\/:*?"<>|#^\[\],;]', "", str(name)).strip().strip(".")
    name = re.sub(r"\s+", "_" if underscore else " ", name)
    return name[:120]


def parse_frontmatter(text: str) -> tuple[dict, str]:
    m = FM_RE.match(text)
    if not m:
        return {}, text
    data = {}
    for line in m.group(1).splitlines():
        if not line.strip() or line.lstrip().startswith("#") or ":" not in line:
            continue
        if line[0] in " \t-":
            continue  # verschachtelte Werte / Listen-Einträge ignorieren
        k, v = line.split(":", 1)
        v = v.strip()
        if len(v) >= 2 and v[0] == v[-1] and v[0] in "\"'":
            v = v[1:-1]
        data[k.strip().lower()] = v
    return data, text[m.end():]


def fm_value(v) -> str:
    v = "" if v is None else str(v)
    if v.startswith("[["):  # Wiki-Link als Property: in Obsidian nur in Anführungszeichen gültig
        return json.dumps(v, ensure_ascii=False)
    if re.search(r"[:#]\s|^[\[{&*!|>%@`]", v) and not re.match(r"^\[.*\]$", v):
        return json.dumps(v, ensure_ascii=False)
    return v


def set_frontmatter(text: str, values: dict) -> str:
    m = FM_RE.match(text)
    if not m:
        block = [f"{k}: {fm_value(v)}" for k, v in values.items()]
        return "---\n" + "\n".join(block) + "\n---\n" + text
    block = m.group(1).rstrip("\r\n").split("\n") if m.group(1).strip() else []
    for k, v in values.items():
        line = f"{k}: {fm_value(v)}"
        for i, existing in enumerate(block):
            if re.match(rf"^{re.escape(k)}\s*:", existing, re.I):
                block[i] = line
                break
        else:
            block.append(line)
    return "---\n" + "\n".join(block) + "\n---\n" + text[m.end():]


def parse_date(v) -> dt.date | None:
    if not v:
        return None
    s = str(v).strip().strip("[]\"' ")
    if not s:
        return None
    try:
        return dt.date.fromisoformat(s[:10])
    except ValueError:
        pass
    for fmt in ("%d.%m.%Y", "%d.%m.%y", "%Y/%m/%d", "%d/%m/%Y"):
        try:
            return dt.datetime.strptime(s, fmt).date()
        except ValueError:
            continue
    return None


def iso(d: dt.date | None) -> str | None:
    return d.isoformat() if d else None


def task_kategorie(t: dict, heute: dt.date) -> str:
    """heute | ueberfaellig | geplant | ohne_datum | erledigt"""
    if t.get("status") == "erledigt":
        return "erledigt"
    start = parse_date(t.get("start"))
    ende = parse_date(t.get("ende"))
    if not start and not ende:
        return "ohne_datum"
    start = start or ende
    ende = ende or start
    if ende < heute:
        return "ueberfaellig"
    if start > heute:
        return "geplant"
    return "heute"


def render_vorlage(text: str, werte: dict) -> str:
    for k, v in werte.items():
        text = text.replace("{{" + k + "}}", "" if v is None else str(v))
    return re.sub(r"\{\{[a-z_]+\}\}", "", text)


class Fehler(ValueError):
    """Fehler mit übersetzbarer Meldung (Schlüssel + Werte)."""

    def __init__(self, schluessel: str, **werte):
        self.schluessel, self.werte = schluessel, werte
        super().__init__(sprachen.text(sprachen.STANDARD, schluessel, **werte))


# ---------------------------------------------------------------------------
# Agent
# ---------------------------------------------------------------------------
SCHEMA = """
CREATE TABLE IF NOT EXISTS tasks (
    pfad TEXT PRIMARY KEY,
    titel TEXT, projekt TEXT, start TEXT, ende TEXT,
    status TEXT, prioritaet TEXT, verantwortlich TEXT,
    checks_total INTEGER, checks_done INTEGER,
    erledigt_am TEXT, geaendert TEXT, aktiv INTEGER DEFAULT 1, jourfixe TEXT
);
CREATE TABLE IF NOT EXISTS tagesuebersicht (
    datum TEXT, pfad TEXT, titel TEXT, projekt TEXT,
    kategorie TEXT, status TEXT, ende TEXT, prioritaet TEXT,
    PRIMARY KEY (datum, pfad)
);
CREATE TABLE IF NOT EXISTS notizen (
    pfad TEXT PRIMARY KEY,
    titel TEXT, typ TEXT, projekt TEXT, tags TEXT, kategorie TEXT,
    geaendert TEXT, inhalt TEXT, meta TEXT
);
CREATE TABLE IF NOT EXISTS sync_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    zeitpunkt TEXT, art TEXT, dateien INTEGER, tasks_offen INTEGER,
    tasks_heute INTEGER, tasks_erledigt INTEGER, lcm INTEGER,
    dauer_ms INTEGER, fehler TEXT
);
CREATE INDEX IF NOT EXISTS ix_tasks_status ON tasks(status, aktiv);
CREATE INDEX IF NOT EXISTS ix_notizen_typ ON notizen(typ);
"""


class Agent:
    def __init__(self, cfg: dict | None = None):
        self.cfg = cfg or load_config()
        self._lock = threading.Lock()
        self._init_db()

    # --- Sprache -----------------------------------------------------------
    @property
    def L(self) -> dict:
        return sprachen.hole(self.cfg.get("sprache"))

    def t(self, schluessel: str, **werte) -> str:
        return sprachen.text(self.cfg.get("sprache"), schluessel, **werte)

    def meldung(self, exc: Exception) -> str:
        if isinstance(exc, Fehler):
            return self.t(exc.schluessel, **exc.werte)
        return str(exc)

    @property
    def VORLAGEN(self) -> dict:
        return vorlagen_mod.bauen(self.L)

    def dmy(self, s) -> str:
        d = parse_date(s)
        return d.strftime(self.L["datumformat"]) if d else ""

    # --- Pfade -----------------------------------------------------------
    @property
    def vault(self) -> Path:
        return Path(self.cfg["vault_path"]).expanduser()

    @property
    def db_path(self) -> Path:
        p = Path(self.cfg["db_path"]).expanduser()
        return p if p.is_absolute() else DATA_DIR / p

    def vault_ok(self) -> bool:
        return self.vault.is_dir()

    def ordner(self, key: str) -> Path:
        name = self.cfg.get(key, "") or ""
        return self.vault / name if name else self.vault

    def rel(self, p: Path) -> str:
        return p.relative_to(self.vault).as_posix()

    def abs_in_vault(self, rel: str, root_ok: bool = False) -> Path:
        p = (self.vault / (rel or "")).resolve()
        v = self.vault.resolve()
        if root_ok and p == v:
            return p
        if v not in p.parents:
            raise Fehler("m_pfad_ausserhalb")
        return p

    def obsidian_link(self, rel: str) -> str:
        """Link, der die Notiz in Obsidian öffnet (obsidian://open?path=<absolut>).
        Optional erzwingt "obsidian_vault_name" in config.json die Variante vault=<Name>&file=<Pfad>."""
        name = (self.cfg.get("obsidian_vault_name") or "").strip()
        params = {"vault": name, "file": rel} if name else {"path": str(self.vault / rel)}
        q = urllib.parse.urlencode(params, quote_via=urllib.parse.quote)
        return f"obsidian://open?{q}"

    # --- DB --------------------------------------------------------------
    def db(self) -> sqlite3.Connection:
        con = sqlite3.connect(self.db_path, timeout=30)
        con.row_factory = sqlite3.Row
        return con

    def _init_db(self):
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        with self.db() as con:
            con.executescript(SCHEMA)
            spalten = {r[1] for r in con.execute("PRAGMA table_info(notizen)")}
            if "meta" not in spalten:  # Migration von älteren Versionen
                con.execute("ALTER TABLE notizen ADD COLUMN meta TEXT")
            tspalten = {r[1] for r in con.execute("PRAGMA table_info(tasks)")}
            if "jourfixe" not in tspalten:
                con.execute("ALTER TABLE tasks ADD COLUMN jourfixe TEXT")

    # --- Grundstruktur ---------------------------------------------------
    def ensure_basics(self):
        """Legt Basisordner und Vorlagen an, falls sie fehlen (überschreibt nichts)."""
        if not self.vault_ok():
            raise Fehler("m_vault_fehlt", pfad=str(self.vault))
        for key in ORDNER_KEYS:
            self.ordner(key).mkdir(parents=True, exist_ok=True)
        vdir = self.ordner("vorlagen_ordner")
        for v in self.VORLAGEN.values():
            f = vdir / v["datei"]
            if not f.exists():
                f.write_text(v["text"], encoding="utf-8")

    def vorlage_text(self, typ: str) -> str:
        v = self.VORLAGEN[typ]
        f = self.ordner("vorlagen_ordner") / v["datei"]
        if f.exists():
            return f.read_text(encoding="utf-8")
        return v["text"]

    def _unique(self, path: Path) -> Path:
        if not path.exists():
            return path
        i = 2
        while True:
            cand = path.with_name(f"{path.stem}_{i}{path.suffix}")
            if not cand.exists():
                return cand
            i += 1

    def sprache_setzen(self, code: str) -> bool:
        """Sprache wechseln. In einem Vault ohne Projekte werden auch Ordnernamen und
        Projektstruktur an die neue Sprache angepasst. Rückgabe: True, wenn Ordner angepasst wurden."""
        neu = sprachen.hole(code)
        if neu["code"] == self.cfg.get("sprache"):
            return False
        alt = sprachen.hole(self.cfg.get("sprache"))
        self.cfg["sprache"] = neu["code"]
        ordner_neu = False
        if not self.vault_ok() or not self.projekte():
            for k in ORDNER_KEYS:
                if self.cfg.get(k) == alt["ordner"].get(k):
                    self.cfg[k] = neu["ordner"][k]
            self.cfg["projekt_struktur"] = [dict(s) for s in neu["struktur"]]
            self.cfg["projekt_praefix"] = neu["projekt_praefix"]
            ordner_neu = True
        save_config(self.cfg)
        return ordner_neu

    # --- Projekte ----------------------------------------------------------
    def projekt_struktur(self) -> list[dict]:
        return [s for s in self.cfg.get("projekt_struktur") or [] if s.get("name")]

    def ordner_fuer_rolle(self, rolle: str) -> str:
        for s in self.projekt_struktur():
            if s.get("rolle") == rolle:
                return s["name"]
        return ""

    def uebersicht_datei(self, root: Path) -> Path:
        return root / f"{self.cfg.get('projekt_praefix') or '_Projekt_'}{safe_name(root.name, True)}.md"

    def _ist_projektordner(self, d: Path) -> bool:
        if self.uebersicht_datei(d).exists():
            return True
        erste = self.projekt_struktur()[:1]
        return bool(erste) and (d / erste[0]["name"]).is_dir()

    def _readme_schreiben(self, d: Path, projekt: str, zweck: str) -> None:
        readme = d / f"readme_{d.name}.md"
        if readme.exists():
            return
        teile = d.name.split("_", 1)
        titel = (teile[1] if len(teile) == 2 and teile[0].isdigit() else d.name).replace("_", " ")
        kopf = f"# {titel} – {projekt}" if projekt else f"# {titel}"
        readme.write_text(
            f"---\ntyp: readme\nprojekt: {fm_value(projekt)}\nordner: {fm_value(d.name)}\n"
            f"erstellt: {dt.date.today().isoformat()}\ntags: [readme]\n---\n"
            f"{kopf}\n\n## {self.t('r_zweck')}\n{zweck or '-'}\n\n"
            f"## {self.t('r_inhalt')}\n- \n\n## {self.t('r_hinweise')}\n- \n",
            encoding="utf-8")

    def projekte(self) -> list[dict]:
        root = self.ordner("projekt_ordner")
        if not root.is_dir():
            return []
        result = []
        struktur = [s["name"] for s in self.projekt_struktur()]
        with self.db() as con:
            for d in sorted(root.iterdir(), key=lambda p: p.name.lower()):
                if not d.is_dir() or d.name.startswith((".", "_")):
                    continue
                if not self.cfg.get("projekt_ordner") and not self._ist_projektordner(d):
                    continue  # bei Ablage im Vault-Root nur echte Projektordner zeigen
                offen = con.execute(
                    "SELECT COUNT(*) FROM tasks WHERE aktiv=1 AND status!='erledigt' AND projekt=?",
                    (d.name,)).fetchone()[0]
                result.append({"name": d.name, "pfad": self.rel(d), "offen": offen,
                               "link": self.obsidian_link(self.rel(self.uebersicht_datei(d))),
                               "vollstaendig": all((d / o).is_dir() for o in struktur)})
        return result

    def projekt_unterordner(self, projekt: str, max_tiefe: int = 3) -> list[dict]:
        """Alle Unterordner eines Projekts, direkt aus dem Vault gelesen."""
        root = self.ordner("projekt_ordner") / safe_name(projekt)
        if not projekt or not root.is_dir():
            return []
        out: list[dict] = []

        def walk(d: Path, tiefe: int):
            try:
                kinder = sorted((k for k in d.iterdir() if k.is_dir()), key=lambda p: p.name.lower())
            except OSError:
                return
            for k in kinder:
                if k.name.startswith("."):
                    continue
                out.append({"pfad": k.relative_to(root).as_posix(), "name": k.name, "tiefe": tiefe})
                if tiefe + 1 < max_tiefe:
                    walk(k, tiefe + 1)
        walk(root, 0)
        return out

    def projekte_ergaenzen(self) -> tuple[int, int]:
        """Fehlende Standardordner (inkl. readme) in allen Projekten anlegen. Nichts wird überschrieben."""
        n_proj = n_ord = 0
        for p in self.projekte():
            if p["vollstaendig"]:
                continue
            root = self.ordner("projekt_ordner") / p["name"]
            fehlend = [s for s in self.projekt_struktur() if not (root / s["name"]).is_dir()]
            self.projekt_anlegen(p["name"])
            n_proj += 1
            n_ord += len(fehlend)
        return n_proj, n_ord

    def projekt_anlegen(self, name: str, kunde: str = "", beschreibung: str = "",
                        projektleitung: str = "", ende: str = "") -> Path:
        self.ensure_basics()
        name = safe_name(name)
        if not name:
            raise Fehler("m_projektname_fehlt")
        root = self.ordner("projekt_ordner") / name
        root.mkdir(parents=True, exist_ok=True)
        heute = dt.date.today().isoformat()
        struktur = self.projekt_struktur()
        for s in struktur:
            d = root / s["name"]
            d.mkdir(exist_ok=True)
            self._readme_schreiben(d, name, s.get("zweck", ""))
        uebersicht = self.uebersicht_datei(root)
        kopf_struktur = f"## {self.t('p_struktur')}\n"
        if uebersicht.exists():  # neue Standardordner in der Übersicht nachtragen
            text = uebersicht.read_text(encoding="utf-8")
            fehlend = [s["name"] for s in struktur if f"/{s['name']}/readme_{s['name']}|" not in text]
            if fehlend and kopf_struktur in text:
                neu = "".join(f"- [[{self.rel(root / o / f'readme_{o}')}|{o}]]\n" for o in fehlend)
                kopf, rest = text.split(kopf_struktur, 1)
                block_ende = rest.find("\n\n")
                block_ende = len(rest) if block_ende < 0 else block_ende + 1
                zeilen = [z for z in (rest[:block_ende] + neu).split("\n") if z.strip()]
                if all(z.startswith("- [[") for z in zeilen):
                    zeilen.sort(key=lambda z: z.rsplit("|", 1)[-1].lower())
                uebersicht.write_text(kopf + kopf_struktur + "\n".join(zeilen) + "\n" + rest[block_ende:],
                                      encoding="utf-8")
        else:
            links = "\n".join(f"- [[{self.rel(root / s['name'] / ('readme_' + s['name']))}|{s['name']}]]"
                              for s in struktur)
            ende_d = iso(parse_date(ende)) or ""
            uebersicht.write_text(
                f"---\ntyp: projekt\ntitel: {fm_value(name)}\nprojekt: {fm_value(name)}\n"
                f"kunde: {fm_value(kunde)}\nprojektleitung: {fm_value(projektleitung)}\n"
                f"status: aktiv\nstart: {heute}\nende: {ende_d}\nerstellt: {heute}\ntags: [projekt]\n---\n"
                f"# {self.t('p_titel')}: {name}\n\n{beschreibung}\n\n"
                f"## {self.t('p_ziele')}\n- \n\n"
                f"## {self.t('p_meilensteine')}\n| {self.t('p_meilenstein')} | {self.t('p_termin')} | "
                f"{self.t('p_status')} |\n|---|---|---|\n| | | |\n\n"
                f"{kopf_struktur}{links}\n\n"
                f"## {self.t('p_offene_tasks')}\n"
                f"```dataview\nTABLE start, ende, status, prioritaet, verantwortlich\nFROM \"{self.rel(root)}\"\n"
                f"WHERE typ = \"task\" AND status != \"erledigt\"\nSORT ende ASC\n```\n",
                encoding="utf-8")
        return root

    # --- Tasks -------------------------------------------------------------
    def task_anlegen(self, titel: str, start: str = "", ende: str = "", projekt: str = "",
                     prioritaet: str = "mittel", verantwortlich: str = "",
                     beschreibung: str = "", checkliste: str = "",
                     ordner: Path | None = None, extra: dict | None = None, unterordner: str = "") -> Path:
        """Legt Task_<Titel>.md an. ordner: abweichender Zielordner (z.B. Jour Fixe),
        extra: zusätzliche Frontmatter-Felder (z.B. jourfixe)."""
        self.ensure_basics()
        if not titel.strip():
            raise Fehler("m_titel_fehlt")
        start_d = parse_date(start) or dt.date.today()
        ende_d = parse_date(ende) or start_d
        if ende_d < start_d:
            raise Fehler("m_ende_vor_start")
        if prioritaet not in STUFEN:
            prioritaet = "mittel"
        if ordner is not None:
            ziel = ordner
            ziel.mkdir(parents=True, exist_ok=True)
        elif projekt:
            ziel = self.ordner("projekt_ordner") / safe_name(projekt)
            if not ziel.is_dir():
                raise Fehler("m_projekt_fehlt", projekt=projekt)
            unterordner = (unterordner or "").strip().strip("/\\")
            if unterordner:
                proj_root = ziel.resolve()
                ziel = (ziel / unterordner).resolve()
                if proj_root not in ziel.parents:
                    raise Fehler("m_ordner_nicht_im_projekt")
                if not ziel.is_dir():
                    raise Fehler("m_ordner_weg", ordner=unterordner, projekt=projekt)
        else:
            ziel = self.ordner("task_ordner")
        datei = self._unique(ziel / f"Task_{safe_name(titel, True)}.md")
        checks = "\n".join(f"- [ ] {z.strip()}" for z in checkliste.splitlines() if z.strip()) or "- [ ] "
        text = render_vorlage(self.vorlage_text("task"), {
            "title": titel.strip(), "date": dt.date.today().isoformat(), "projekt": projekt,
            "start": iso(start_d), "ende": iso(ende_d), "prioritaet": prioritaet,
            "verantwortlich": verantwortlich, "beschreibung": beschreibung, "checkliste": checks,
        })
        # Pflichtfelder absichern, auch wenn die Vorlage in Obsidian verändert wurde
        text = set_frontmatter(text, {"typ": "task", "titel": titel.strip(), "start": iso(start_d),
                                      "ende": iso(ende_d), "status": "offen", "projekt": projekt,
                                      "prioritaet": prioritaet, "verantwortlich": verantwortlich,
                                      **(extra or {})})
        datei.write_text(text, encoding="utf-8")
        with self.db() as con:
            self._index_file(con, datei, dt.date.today())
        return datei

    def task_status_setzen(self, rel: str, status: str) -> None:
        if status not in TASK_STATUS:
            raise Fehler("m_status_ungueltig")
        p = self.abs_in_vault(rel)
        text = p.read_text(encoding="utf-8")
        werte = {"status": status, "erledigt_am": dt.date.today().isoformat() if status == "erledigt" else ""}
        p.write_text(set_frontmatter(text, werte), encoding="utf-8")
        with self.db() as con:
            self._index_file(con, p, dt.date.today())
            self._tagesuebersicht(con, dt.date.today())

    def task_verschieben(self, rel: str, tage: int) -> None:
        """Start/Ende um n Tage verschieben (z.B. 'auf morgen')."""
        p = self.abs_in_vault(rel)
        text = p.read_text(encoding="utf-8")
        fm, _ = parse_frontmatter(text)
        heute = dt.date.today()
        start = parse_date(fm.get("start")) or heute
        ende = parse_date(fm.get("ende")) or start
        dauer = (ende - start).days
        neu_start = max(start, heute) + dt.timedelta(days=tage)
        p.write_text(set_frontmatter(text, {"start": iso(neu_start),
                                            "ende": iso(neu_start + dt.timedelta(days=dauer))}),
                     encoding="utf-8")
        with self.db() as con:
            self._index_file(con, p, heute)
            self._tagesuebersicht(con, heute)

    def tasks(self, heute: dt.date | None = None, projekt: str = "") -> dict[str, list[dict]]:
        heute = heute or dt.date.today()
        sql = "SELECT * FROM tasks WHERE aktiv=1"
        args: list = []
        if projekt:
            sql += " AND projekt=?"
            args.append(projekt)
        gruppen = {k: [] for k in ("heute", "ueberfaellig", "geplant", "ohne_datum", "erledigt")}
        with self.db() as con:
            for r in con.execute(sql, args):
                t = dict(r)
                t["kategorie"] = task_kategorie(t, heute)
                t["link"] = self.obsidian_link(t["pfad"])
                e = parse_date(t["ende"])
                t["rest_tage"] = (e - heute).days if e else None
                gruppen[t["kategorie"]].append(t)

        def key(t):
            return (PRIO_ORDER.get((t["prioritaet"] or "").lower(), 1), t["ende"] or "9999", t["titel"].lower())
        for k in ("heute", "ueberfaellig", "ohne_datum"):
            gruppen[k].sort(key=key)
        gruppen["geplant"].sort(key=lambda t: (t["start"] or "9999", key(t)))
        gruppen["erledigt"].sort(key=lambda t: t["erledigt_am"] or "", reverse=True)
        return gruppen

    # --- Projektdokumente aus Vorlagen ---------------------------------------------
    def notiz_typen(self) -> dict[str, dict]:
        out = {}
        for k in NOTIZ_TYPEN:
            v = dict(self.VORLAGEN[k])
            v["ordner"] = self.ordner_fuer_rolle(TYP_ROLLE[k])
            out[k] = v
        return out

    def notiz_anlegen(self, typ: str, titel: str, projekt: str = "") -> Path:
        self.ensure_basics()
        if typ not in NOTIZ_TYPEN:
            raise Fehler("m_typ_unbekannt")
        if not titel.strip():
            raise Fehler("m_titel_fehlt")
        v = self.VORLAGEN[typ]
        heute = dt.date.today()
        if projekt:
            root = self.ordner("projekt_ordner") / safe_name(projekt)
            if not root.is_dir():
                raise Fehler("m_projekt_fehlt", projekt=projekt)
            ziel = root / (self.ordner_fuer_rolle(TYP_ROLLE[typ]) or "")
        else:
            ziel = self.ordner("notiz_ordner") / safe_name(v["label"].split(" ")[0])
        ziel.mkdir(parents=True, exist_ok=True)
        name = v["dateiname"].format(date=heute.isoformat(), monat=heute.strftime("%Y-%m"),
                                     titel=safe_name(titel), titel_=safe_name(titel, True))
        datei = self._unique(ziel / f"{name}.md")
        text = render_vorlage(self.vorlage_text(typ), {
            "title": titel.strip(), "date": heute.isoformat(), "projekt": projekt})
        text = set_frontmatter(text, {"typ": typ, "titel": titel.strip(), "projekt": projekt})
        datei.write_text(text, encoding="utf-8")
        with self.db() as con:
            self._index_file(con, datei, heute)
        return datei

    def vorlagen_liste(self) -> list[dict]:
        """Alle .md-Dateien im Vorlagen-Ordner (auch eigene), mit vorgeschlagenem Zielordner.
        Eigene Vorlagen können im Frontmatter 'zielordner: <Ordner>' setzen."""
        self.ensure_basics()
        vdir = self.ordner("vorlagen_ordner")
        bekannt = {v["datei"].lower(): (k, v) for k, v in self.VORLAGEN.items()}
        out = []
        for f in sorted(vdir.rglob("*.md"), key=lambda p: p.name.lower()):
            fm, _ = parse_frontmatter(f.read_text(encoding="utf-8", errors="replace"))
            key, v = bekannt.get(f.name.lower(), (None, None))
            typ = (fm.get("typ") or key or "").lower()
            ziel = fm.get("zielordner") or (self.ordner_fuer_rolle(TYP_ROLLE.get(typ, "")) if typ else "")
            name = (v or {}).get("label") or re.sub(r"^(Vorlage|Template|Modele|Modello|Plantilla|Sablon)[_ -]*", "",
                                                      f.stem, flags=re.I).replace("_", " ")
            out.append({"datei": f.relative_to(vdir).as_posix(), "name": name, "typ": typ,
                        "ziel": ziel, "eigen": v is None, "link": self.obsidian_link(self.rel(f))})
        return out

    def aus_vorlage_anlegen(self, datei: str, titel: str, projekt: str = "", unterordner: str = "") -> Path:
        """Neue Notiz aus einer beliebigen Vorlage in einem Projekt(-Unterordner) anlegen."""
        self.ensure_basics()
        titel = titel.strip()
        if not titel:
            raise Fehler("m_titel_fehlt")
        vdir = self.ordner("vorlagen_ordner").resolve()
        vorlage = (vdir / datei).resolve()
        if vdir not in vorlage.parents or not vorlage.is_file():
            raise Fehler("m_vorlage_fehlt")
        heute = dt.date.today()
        if projekt:
            root = (self.ordner("projekt_ordner") / safe_name(projekt)).resolve()
            if not root.is_dir():
                raise Fehler("m_projekt_fehlt", projekt=projekt)
            ziel = (root / unterordner.strip().strip("/\\")).resolve() if unterordner.strip() else root
            if ziel != root and root not in ziel.parents:
                raise Fehler("m_ordner_nicht_im_projekt")
            if not ziel.is_dir():
                raise Fehler("m_ordner_weg", ordner=unterordner, projekt=projekt)
        else:
            ziel = self.ordner("notiz_ordner")
            ziel.mkdir(parents=True, exist_ok=True)
        text = vorlage.read_text(encoding="utf-8")
        fm, _ = parse_frontmatter(text)
        typ = (fm.get("typ") or "").lower()
        praefix = {"task": "Task_"}.get(typ, "")
        datei_neu = self._unique(ziel / f"{praefix}{safe_name(titel, bool(praefix))}.md")
        text = render_vorlage(text, {"title": titel, "date": heute.isoformat(), "projekt": projekt,
                                     "start": heute.isoformat(), "ende": heute.isoformat(),
                                     "datum": heute.isoformat(), "prioritaet": "mittel", "status": ""})
        werte = {"titel": titel}
        if projekt:
            werte["projekt"] = projekt
        if typ == "task":
            werte.update({"status": "offen", "start": heute.isoformat(), "ende": heute.isoformat()})
        text = set_frontmatter(text, werte)
        text = re.sub(r"(?m)^zielordner:.*\n", "", text, count=1)  # Vorlagen-Hilfsfeld nicht übernehmen
        datei_neu.write_text(text, encoding="utf-8")
        with self.db() as con:
            self._index_file(con, datei_neu, heute)
        return datei_neu

    def letzte_notizen(self, limit: int = 15) -> list[dict]:
        with self.db() as con:
            rows = con.execute("SELECT pfad, titel, typ, projekt, geaendert FROM notizen "
                               "WHERE typ NOT IN ('readme','index','planer','vorlage') "
                               "ORDER BY geaendert DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r, link=self.obsidian_link(r["pfad"])) for r in rows]

    # --- Team ---------------------------------------------------------------------
    def eintraege(self, typ: str) -> list[dict]:
        """Alle Notizen eines Typs inkl. Frontmatter-Feldern (aus dem letzten Sync)."""
        with self.db() as con:
            rows = con.execute("SELECT pfad, titel, projekt, kategorie, geaendert, meta FROM notizen "
                               "WHERE typ=? ORDER BY titel COLLATE NOCASE", (typ,)).fetchall()
        out = []
        for r in rows:
            d = json.loads(r["meta"] or "{}")
            d.update({k: r[k] for k in ("pfad", "titel", "projekt", "geaendert")})
            d["link"] = self.obsidian_link(r["pfad"])
            out.append(d)
        return out

    def _eintrag_datei(self, ordner_key: str, unterordner: str, dateiname: str) -> Path:
        self.ensure_basics()
        ziel = self.ordner(ordner_key)
        if unterordner:
            ziel = ziel / safe_name(unterordner)
        ziel.mkdir(parents=True, exist_ok=True)
        return self._unique(ziel / f"{dateiname}.md")

    def _eintrag_schreiben(self, typ: str, datei: Path, werte: dict) -> Path:
        werte = {k: ("" if v is None else str(v).strip()) for k, v in werte.items()}
        werte.setdefault("date", dt.date.today().isoformat())
        text = render_vorlage(self.vorlage_text(typ), werte)
        text = set_frontmatter(text, {"typ": typ, "titel": werte["title"]})
        datei.write_text(text, encoding="utf-8")
        with self.db() as con:
            self._index_file(con, datei, dt.date.today())
        return datei

    def person_anlegen(self, d: dict) -> Path:
        name = (d.get("titel") or "").strip()
        if not name:
            raise Fehler("m_name_fehlt")
        datei = self.ordner("team_ordner") / f"{safe_name(name)}.md"
        if datei.exists():
            raise Fehler("m_person_existiert", pfad=self.rel(datei))
        datei = self._eintrag_datei("team_ordner", "", safe_name(name))
        return self._eintrag_schreiben("person", datei, {
            "title": name, **{k: d.get(k) for k in ("kuerzel", "rolle", "team", "email", "telefon",
                                                     "standort", "vertretung", "skills")}})

    def team(self) -> list[dict]:
        """Teammitglieder inkl. offener Tasks (Zuordnung über 'verantwortlich': Name, Vorname oder Kürzel)."""
        personen = self.eintraege("person")
        g = self.tasks()
        offen = [t for k in ("ueberfaellig", "heute", "geplant", "ohne_datum") for t in g[k]]
        for p in personen:
            schluessel = {x.lower() for x in (p["titel"], p.get("kuerzel") or "") if x}
            p["tasks"] = [t for t in offen
                          if schluessel & {x.strip() for x in re.split(r"[,;/&]", (t["verantwortlich"] or "").lower())}]
            p["ueberfaellig"] = sum(t["kategorie"] == "ueberfaellig" for t in p["tasks"])
        return personen

    # --- Jour Fixe -------------------------------------------------------------
    @staticmethod
    def _jf_naechster(datum: dt.date, turnus: str) -> dt.date | None:
        tage = JF_TURNUS.get(turnus)
        if tage is None:
            return None
        if tage:
            return datum + dt.timedelta(days=tage)
        m = datum.month % 12 + 1
        j = datum.year + (datum.month == 12)
        for tag in (datum.day, 30, 29, 28):
            try:
                return dt.date(j, m, tag)
            except ValueError:
                continue
        return None

    def jf_pendenzen(self, serie: str = "", alle: bool = False) -> list[dict]:
        """Tasks mit Feld 'jourfixe' (= Pendenzen), offen zuerst nach Fälligkeit."""
        g = self.tasks()
        gruppen = ("ueberfaellig", "heute", "geplant", "ohne_datum") + (("erledigt",) if alle else ())
        out = [t for k in gruppen for t in g[k] if t.get("jourfixe")]
        if serie:
            out = [t for t in out if t["jourfixe"].lower() == serie.lower()]
        out.sort(key=lambda t: (t["status"] == "erledigt", t["ende"] or "9999", t["titel"].lower()))
        return out

    def jf_sitzungen(self, serie: str = "") -> list[dict]:
        s = [e for e in self.eintraege("jourfixe") if not serie or (e.get("serie") or "").lower() == serie.lower()]
        s.sort(key=lambda e: iso(parse_date(e.get("datum"))) or "", reverse=True)
        return s

    def jf_serien(self) -> list[dict]:
        """Serien = Unterordner im Jour-Fixe-Ordner, ergänzt um Serien aus Sitzungen/Pendenzen."""
        heute = dt.date.today()
        namen: dict[str, str] = {}
        jdir = self.ordner("jourfixe_ordner")
        if jdir.is_dir():
            for d in jdir.iterdir():
                if d.is_dir() and not d.name.startswith("."):
                    namen.setdefault(d.name.lower(), d.name)
        sitzungen = self.jf_sitzungen()
        pendenzen = self.jf_pendenzen()
        for x in [e.get("serie") for e in sitzungen] + [t["jourfixe"] for t in pendenzen]:
            if x:
                namen.setdefault(x.lower(), x)
        out = []
        for key, name in sorted(namen.items()):
            ss = [e for e in sitzungen if (e.get("serie") or "").lower() == key]
            pp = [t for t in pendenzen if t["jourfixe"].lower() == key]
            letzte = ss[0] if ss else None
            naechster = parse_date(letzte.get("naechster_termin")) if letzte else None
            out.append({"name": name, "sitzungen": len(ss), "letzte": letzte,
                        "naechster": iso(naechster), "naechster_in": (naechster - heute).days if naechster else None,
                        "offen": len(pp), "ueberfaellig": sum(t["kategorie"] == "ueberfaellig" for t in pp),
                        "projekt": (letzte or {}).get("projekt", ""),
                        "teilnehmer": (letzte or {}).get("teilnehmer", ""),
                        "moderation": (letzte or {}).get("moderation", "")})
        return out

    def jf_sitzung_anlegen(self, d: dict) -> Path:
        serie = safe_name(d.get("serie") or "")
        if not serie:
            raise Fehler("m_serie_fehlt")
        datum = parse_date(d.get("datum")) or dt.date.today()
        naechster = parse_date(d.get("naechster_termin")) or self._jf_naechster(datum, d.get("turnus") or "")
        offen = self.jf_pendenzen(serie)
        if offen:
            zeilen = [f"| {self.t('jf_pendenz')} | {self.t('verantwortlich')} | {self.t('faellig')} | "
                      f"{self.t('status')} |", "|---|---|---|---|"]
            zeilen += [f"| [[{t['pfad'][:-3]}\\|{t['titel']}]] | {t['verantwortlich'] or ''} | {self.dmy(t['ende'])} | "
                       f"{self.t('st_' + t['status'])} |" for t in offen]
            pendenzen = "\n".join(zeilen)
        else:
            pendenzen = self.t("jf_keine_pendenzen")
        agenda = "\n".join(f"{i}. {z.strip()}" for i, z in enumerate(
            (z for z in (d.get("agenda") or "").splitlines() if z.strip()), 1)) or f"1. {self.t('jf_pendenzen_durchgehen')}\n2. "
        datei = self._eintrag_datei("jourfixe_ordner", serie,
                                    f"{self.L['jf_praefix']}{datum.isoformat()}_{safe_name(serie, True)}")
        return self._eintrag_schreiben("jourfixe", datei, {
            "title": f"{self.t('nav_jourfixe')} {serie} {self.dmy(datum.isoformat())}", "serie": serie,
            "datum": datum.isoformat(), "projekt": d.get("projekt"), "moderation": d.get("moderation"),
            "teilnehmer": d.get("teilnehmer"), "naechster_termin": iso(naechster) or "",
            "agenda": agenda, "pendenzen": pendenzen})

    def jf_pendenz_anlegen(self, d: dict) -> Path:
        serie = safe_name(d.get("serie") or "")
        if not serie:
            raise Fehler("m_serie_waehlen")
        projekt = d.get("projekt") or ""
        if projekt and not (self.ordner("projekt_ordner") / safe_name(projekt)).is_dir():
            projekt = ""
        sitzung = self.jf_sitzungen(serie)
        extra = {"jourfixe": serie}
        beschreibung = d.get("beschreibung") or ""
        if sitzung:
            extra["jf_sitzung"] = f"[[{sitzung[0]['pfad'][:-3]}]]"
            beschreibung = (beschreibung + "\n\n" if beschreibung else "") + \
                f"{self.t('jf_aus_sitzung')}: [[{sitzung[0]['pfad'][:-3]}|{sitzung[0]['titel']}]]"
        heute = dt.date.today()
        ende = parse_date(d.get("ende"))
        if not ende:  # ohne Fälligkeit: bis zum nächsten Termin der Serie
            info = next((s for s in self.jf_serien() if s["name"].lower() == serie.lower()), None)
            ende = parse_date(info["naechster"]) if info and info["naechster"] else heute
        start = parse_date(d.get("start")) or min(heute, ende)
        return self.task_anlegen(d.get("titel", ""), iso(start), iso(ende), projekt,
                                 d.get("prioritaet") or "mittel", d.get("verantwortlich", ""), beschreibung,
                                 d.get("checkliste", ""),
                                 ordner=self.ordner("jourfixe_ordner") / serie / self.L["pendenzen_ordner"],
                                 extra=extra)

    # --- Suche ---------------------------------------------------------------
    def suche(self, q: str, typ: str = "", limit: int = 100) -> list[dict]:
        woerter = [w for w in q.split() if w]
        if not woerter:
            return []
        sql = "SELECT pfad, titel, typ, projekt, inhalt FROM notizen WHERE 1=1"
        args: list = []
        for w in woerter:
            sql += " AND (titel LIKE ? OR inhalt LIKE ? OR pfad LIKE ?)"
            args += [f"%{w}%"] * 3
        if typ:
            sql += " AND typ=?"
            args.append(typ)
        sql += " ORDER BY geaendert DESC LIMIT ?"
        args.append(limit)
        out = []
        with self.db() as con:
            for r in con.execute(sql, args):
                inhalt = r["inhalt"] or ""
                pos = inhalt.lower().find(woerter[0].lower())
                snippet = inhalt[max(0, pos - 80): pos + 160] if pos >= 0 else inhalt[:200]
                treffer_titel = sum(w.lower() in (r["titel"] or "").lower() for w in woerter)
                out.append({"pfad": r["pfad"], "titel": r["titel"], "typ": r["typ"],
                            "projekt": r["projekt"], "snippet": snippet.replace("\n", " "),
                            "link": self.obsidian_link(r["pfad"]), "score": treffer_titel})
        out.sort(key=lambda x: -x["score"])
        return out

    # --- Sync ------------------------------------------------------------------
    def _iter_md(self):
        skip = {".obsidian", ".trash", ".git", "node_modules"}
        for p in self.vault.rglob("*.md"):
            if any(part in skip for part in p.relative_to(self.vault).parts):
                continue
            yield p

    def _projekt_aus_pfad(self, rel: str) -> str:
        po = self.cfg.get("projekt_ordner") or ""
        parts = rel.split("/")
        if po:
            if len(parts) > 2 and parts[0] == po:
                return parts[1]
        elif len(parts) > 1 and self._ist_projektordner(self.vault / parts[0]):
            return parts[0]
        return ""

    def _index_file(self, con: sqlite3.Connection, p: Path, heute: dt.date):
        rel = self.rel(p)
        text = p.read_text(encoding="utf-8", errors="replace")
        fm, body = parse_frontmatter(text)
        typ = (fm.get("typ") or fm.get("type") or "").lower()
        name_l = p.name.lower()
        vorlagen = self.cfg.get("vorlagen_ordner") or "_Vorlagen"
        ist_vorlage = rel.startswith(vorlagen + "/")
        projekt = fm.get("projekt") or self._projekt_aus_pfad(rel)
        titel = fm.get("titel") or fm.get("title") or p.stem
        geaendert = dt.datetime.fromtimestamp(p.stat().st_mtime).isoformat(timespec="seconds")
        if ist_vorlage:
            typ = "vorlage"

        if not ist_vorlage and (name_l.startswith("task_") or typ == "task"):
            typ = "task"
            if not fm.get("titel") and name_l.startswith("task_"):
                titel = p.stem[5:].replace("_", " ")
            checks = CHECK_RE.findall(body)
            total, done = len(checks), sum(c.lower() == "x" for c in checks)
            raw = (fm.get("status") or "").lower().strip()
            if raw in ERLEDIGT_WERTE or (fm.get("erledigt") or "").lower() in ERLEDIGT_WERTE:
                status = "erledigt"
            elif not raw and total and total == done:
                status = "erledigt"
            elif raw in TASK_STATUS:
                status = raw
            else:
                status = "offen"
            erledigt_am = iso(parse_date(fm.get("erledigt_am"))) or (heute.isoformat() if status == "erledigt" else None)
            con.execute("""
                INSERT INTO tasks (pfad, titel, projekt, start, ende, status, prioritaet, verantwortlich,
                                   checks_total, checks_done, erledigt_am, geaendert, aktiv, jourfixe)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,1,?)
                ON CONFLICT(pfad) DO UPDATE SET
                    titel=excluded.titel, projekt=excluded.projekt, start=excluded.start, ende=excluded.ende,
                    status=excluded.status, prioritaet=excluded.prioritaet, verantwortlich=excluded.verantwortlich,
                    checks_total=excluded.checks_total, checks_done=excluded.checks_done,
                    erledigt_am=CASE WHEN excluded.status='erledigt'
                                     THEN COALESCE(tasks.erledigt_am, excluded.erledigt_am) ELSE NULL END,
                    geaendert=excluded.geaendert, aktiv=1, jourfixe=excluded.jourfixe
            """, (rel, titel, projekt, iso(parse_date(fm.get("start"))), iso(parse_date(fm.get("ende") or fm.get("end"))),
                  status, (fm.get("prioritaet") or "mittel").lower(), fm.get("verantwortlich", ""),
                  total, done, erledigt_am, geaendert, (fm.get("jourfixe") or "").strip()))

        if not typ and not name_l.startswith(("readme_", "_")):
            for key, t in (("team_ordner", "person"), ("jourfixe_ordner", "jourfixe")):
                o = self.cfg.get(key) or ""
                if o and rel.startswith(o + "/"):
                    typ = t
                    break
        con.execute("INSERT OR REPLACE INTO notizen (pfad, titel, typ, projekt, tags, kategorie, geaendert, inhalt, meta) "
                    "VALUES (?,?,?,?,?,?,?,?,?)",
                    (rel, titel, typ or "notiz", projekt, fm.get("tags", ""), fm.get("kategorie", ""),
                     geaendert, body, json.dumps(fm, ensure_ascii=False)))

    def _tagesuebersicht(self, con: sqlite3.Connection, heute: dt.date):
        d = heute.isoformat()
        con.execute("DELETE FROM tagesuebersicht WHERE datum=?", (d,))
        for r in con.execute("SELECT * FROM tasks WHERE aktiv=1").fetchall():
            t = dict(r)
            kat = task_kategorie(t, heute)
            if kat == "erledigt" and t["erledigt_am"] != d:
                continue
            con.execute("INSERT INTO tagesuebersicht VALUES (?,?,?,?,?,?,?,?)",
                        (d, t["pfad"], t["titel"], t["projekt"], kat, t["status"], t["ende"], t["prioritaet"]))

    def _planer_notiz(self, heute: dt.date):
        g = self.tasks(heute)
        n_tage = int(self.cfg.get("demnaechst_tage", 7))
        bald = [t for t in g["geplant"] if parse_date(t["start"]) <= heute + dt.timedelta(days=n_tage)]
        gestern = (heute - dt.timedelta(days=1)).isoformat()
        erledigt = [t for t in g["erledigt"] if (t["erledigt_am"] or "") >= gestern]

        def zeile(t):
            teile = [f"- [[{t['pfad'][:-3]}|{t['titel']}]]"]
            if t["projekt"]:
                teile.append(f"· {t['projekt']}")
            if t["ende"]:
                teile.append(f"· {self.t('bis')} {self.dmy(t['ende'])}")
            if (t["prioritaet"] or "") == "hoch":
                teile.append(f"· ❗{self.t('pr_hoch')}")
            if t["checks_total"]:
                teile.append(f"· {t['checks_done']}/{t['checks_total']} ✓")
            return " ".join(teile)

        wt = self.L["wochentage"][heute.weekday()]
        z = ["---", "typ: planer", f"datum: {heute.isoformat()}",
             f"aktualisiert: {dt.datetime.now().isoformat(timespec='minutes')}", "---",
             f"# {self.t('pl_titel')} {wt}, {heute.strftime(self.L['datumformat'])}",
             f"> {self.t('pl_hinweis')}", ""]
        for titel, liste in ((f"🎯 {self.t('heute')} ({len(g['heute'])})", g["heute"]),
                             (f"⚠️ {self.t('ueberfaellig')} ({len(g['ueberfaellig'])})", g["ueberfaellig"]),
                             (f"📅 {self.t('pl_demnaechst', n=n_tage)} ({len(bald)})", bald),
                             (f"✅ {self.t('pl_erledigt')} ({len(erledigt)})", erledigt)):
            z += [f"## {titel}"] + ([zeile(t) for t in liste] or ["- –"]) + [""]
        inhalt = "\n".join(z)
        pdir = self.ordner("planer_ordner")
        archiv = pdir / self.L["planer"]["archiv"]
        archiv.mkdir(parents=True, exist_ok=True)
        (pdir / f"{self.L['planer']['datei']}.md").write_text(inhalt, encoding="utf-8")
        (archiv / f"{self.L['planer']['praefix']}{heute.isoformat()}.md").write_text(inhalt, encoding="utf-8")

    def sync(self, art: str = "manuell") -> dict:
        with self._lock:
            t0 = time.time()
            heute = dt.date.today()
            self.ensure_basics()
            dateien = 0
            with self.db() as con:
                con.execute("UPDATE tasks SET aktiv=0")
                con.execute("DELETE FROM notizen")
                for p in self._iter_md():
                    try:
                        self._index_file(con, p, heute)
                        dateien += 1
                    except Exception as exc:  # einzelne defekte Datei soll den Sync nicht stoppen
                        print(f"[WARN] {p}: {exc}", file=sys.stderr)
                con.execute("DELETE FROM tasks WHERE aktiv=0")
                self._tagesuebersicht(con, heute)
            self._planer_notiz(heute)
            g = self.tasks(heute)
            stats = {"zeitpunkt": dt.datetime.now().isoformat(timespec="seconds"), "art": art,
                     "dateien": dateien,
                     "tasks_offen": sum(len(g[k]) for k in ("heute", "ueberfaellig", "geplant", "ohne_datum")),
                     "tasks_heute": len(g["heute"]), "tasks_erledigt": len(g["erledigt"]),
                     "dauer_ms": int((time.time() - t0) * 1000)}
            with self.db() as con:
                con.execute("INSERT INTO sync_log (zeitpunkt, art, dateien, tasks_offen, tasks_heute, "
                            "tasks_erledigt, dauer_ms) VALUES (:zeitpunkt,:art,:dateien,:tasks_offen,"
                            ":tasks_heute,:tasks_erledigt,:dauer_ms)", stats)
            return stats

    def sync_log(self, limit: int = 20) -> list[dict]:
        with self.db() as con:
            return [dict(r) for r in con.execute(
                "SELECT * FROM sync_log ORDER BY id DESC LIMIT ?", (limit,))]

    def letzter_sync(self) -> dict | None:
        log = self.sync_log(1)
        return log[0] if log else None

    # --- Zeitplan ----------------------------------------------------------------
    def geplanter_sync_faellig(self, jetzt: dt.datetime | None = None) -> bool:
        jetzt = jetzt or dt.datetime.now()
        h, m = (int(x) for x in str(self.cfg.get("sync_zeit", "04:00")).split(":"))
        slot = jetzt.replace(hour=h, minute=m, second=0, microsecond=0)
        if jetzt < slot:
            slot -= dt.timedelta(days=1)
        with self.db() as con:
            last = con.execute("SELECT MAX(zeitpunkt) FROM sync_log WHERE art='geplant'").fetchone()[0]
        return last is None or dt.datetime.fromisoformat(last) < slot

    def starte_scheduler(self):
        def loop():
            while True:
                try:
                    if self.vault_ok() and self.geplanter_sync_faellig():
                        s = self.sync("geplant")
                        print(f"[Agent] Sync: {s['tasks_heute']} / {s['tasks_offen']}")
                except Exception as exc:
                    print(f"[Agent] Sync: {exc}", file=sys.stderr)
                time.sleep(60)
        threading.Thread(target=loop, daemon=True, name="agent-scheduler").start()


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def main(argv=None):
    for strom in (sys.stdout, sys.stderr):  # Windows-Konsole: Sonderzeichen nie zum Absturz führen lassen
        try:
            strom.reconfigure(errors="replace")
        except (AttributeError, ValueError):
            pass
    ap = argparse.ArgumentParser(description="Obsidian-Agent")
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("sync", help="Vault einlesen und Tagesübersicht schreiben")
    s.add_argument("--geplant", action="store_true", help="als geplanten Tageslauf protokollieren")
    sub.add_parser("heute", help="heutige Tasks anzeigen")
    p = sub.add_parser("projekt", help="neues Projekt anlegen")
    p.add_argument("name")
    e = sub.add_parser("einrichten", help="Sprache und Vault setzen (wird vom Installer genutzt)")
    e.add_argument("--sprache")
    e.add_argument("--vault")
    sub.add_parser("info", help="Konfiguration als JSON ausgeben")
    a = ap.parse_args(argv)

    if a.cmd == "einrichten":
        cfg = load_config(a.sprache)
        agent = Agent(cfg)
        if a.sprache:
            agent.sprache_setzen(a.sprache)
        if a.vault:
            cfg["vault_path"] = str(Path(a.vault).expanduser()).rstrip("/\\") or a.vault
            save_config(cfg)
        print(json.dumps({"config": str(CONFIG_FILE), "sprache": cfg["sprache"],
                          "vault_path": cfg["vault_path"], "vault_ok": agent.vault_ok()}))
        return
    if a.cmd == "info":
        cfg = load_config()
        print(json.dumps({**cfg, "config": str(CONFIG_FILE), "vault_ok": Path(cfg["vault_path"]).expanduser().is_dir()}))
        return

    agent = Agent()
    if a.cmd == "sync":
        st = agent.sync("geplant" if a.geplant else "manuell")
        print(agent.t("m_sync_ok", dateien=st["dateien"], heute=st["tasks_heute"],
                      offen=st["tasks_offen"], ms=st["dauer_ms"]))
    elif a.cmd == "heute":
        g = agent.tasks()
        for k in ("heute", "ueberfaellig"):
            print(f"\n== {agent.t(k).upper()} ({len(g[k])}) ==")
            for t in g[k]:
                print(f"  [{agent.t('pr_' + (t['prioritaet'] or 'mittel'))[:1].upper()}] {t['titel']}  "
                      f"({t['projekt'] or '-'}, {agent.t('bis')} {agent.dmy(t['ende'])})")
    elif a.cmd == "projekt":
        print(agent.rel(agent.projekt_anlegen(a.name)))


if __name__ == "__main__":
    main()
