"""
Obsidian-Agent – Start im Hintergrund (ohne Konsolenfenster, ohne Browser).
Wird beim Anmelden von der geplanten Aufgabe (Windows) bzw. von launchd (macOS) gestartet.
Protokoll: <Datenordner>/logs/gui.log
"""
import logging
import os
import runpy
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parent
os.chdir(BASE)
sys.path[:0] = [str(BASE / "vendor"), str(BASE)]
os.environ["OBSIDIAN_AGENT_NO_BROWSER"] = "1"

import agent  # noqa: E402

log_dir = agent.DATA_DIR / "logs"
log_dir.mkdir(parents=True, exist_ok=True)
log = open(log_dir / "gui.log", "w", encoding="utf-8", buffering=1)
sys.stdout = sys.stderr = log
logging.getLogger("werkzeug").setLevel(logging.WARNING)  # keine Zeile pro Seitenaufruf

try:
    runpy.run_path(str(BASE / "app.py"), run_name="__main__")
except SystemExit:
    raise
except BaseException:
    import traceback
    traceback.print_exc()
    raise
