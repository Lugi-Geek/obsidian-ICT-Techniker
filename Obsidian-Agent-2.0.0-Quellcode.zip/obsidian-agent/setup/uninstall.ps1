﻿# ======================================================================
#  Obsidian-Agent – Deinstallation für Windows (wird vom Uninstaller aufgerufen)
#  Beendet den Agent, entfernt geplante Aufgaben und Verknüpfungen und sichert
#  Einstellungen und Datenbank auf den Desktop. Der Obsidian-Vault bleibt unverändert.
# ======================================================================
param([string]$Sprache = 'de')
$ErrorActionPreference = 'SilentlyContinue'
$Setup = Split-Path -Parent $MyInvocation.MyCommand.Path
. (Join-Path $Setup 'texte.ps1')
$Daten = Join-Path $env:LOCALAPPDATA 'Obsidian-Agent'
Write-Host (T 'deinst')

$Port = 5055
$cfg = Join-Path $Daten 'config.json'
if (Test-Path $cfg) { try { $Port = [int]((Get-Content $cfg -Raw | ConvertFrom-Json).port) } catch {} }
Get-NetTCPConnection -LocalPort $Port -State Listen | ForEach-Object { Stop-Process -Id $_.OwningProcess -Force }

foreach ($t in 'Obsidian-Agent Weboberflaeche', 'Obsidian-Agent Tages-Sync') {
    Unregister-ScheduledTask -TaskName $t -Confirm:$false
}
foreach ($l in (Join-Path ([Environment]::GetFolderPath('Startup')) 'Obsidian-Agent.lnk'),
               (Join-Path ([Environment]::GetFolderPath('Programs')) 'Obsidian-Agent.lnk'),
               (Join-Path ([Environment]::GetFolderPath('Desktop')) 'Obsidian-Agent.lnk')) {
    Remove-Item $l -Force
}

if (Test-Path $Daten) {
    $ziel = Join-Path ([Environment]::GetFolderPath('Desktop')) ('obsidian-agent-backup_' + (Get-Date -Format 'yyyy-MM-dd_HHmm'))
    New-Item -ItemType Directory -Path $ziel -Force | Out-Null
    foreach ($f in 'config.json', 'planer.db') { Copy-Item (Join-Path $Daten $f) $ziel }
    Write-Host (T 'backup' @($ziel))
    Remove-Item $Daten -Recurse -Force
}
Start-Sleep -Seconds 2
