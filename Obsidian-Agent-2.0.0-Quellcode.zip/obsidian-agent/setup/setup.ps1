﻿# ======================================================================
#  Obsidian-Agent – Einrichtung für Windows (wird vom Installer aufgerufen)
#   1. Python suchen, bei Bedarf automatisch installieren (ohne Adminrechte)
#   2. Sprache setzen, Vault wählen, ersten Sync ausführen
#   3. Aufgabe "Obsidian-Agent Weboberflaeche" (Start bei Anmeldung, im Hintergrund)
#      und "Obsidian-Agent Tages-Sync" (täglich, verpasste Läufe werden nachgeholt)
#   4. Verknüpfungen in Startmenü und auf dem Desktop
#  Mehrfach ausführbar: bestehende Einträge werden aktualisiert, nichts geht verloren.
# ======================================================================
param([string]$Sprache = 'de')
$ErrorActionPreference = 'Continue'
$Setup = Split-Path -Parent $MyInvocation.MyCommand.Path
$Dir = Split-Path -Parent $Setup
. (Join-Path $Setup 'texte.ps1')
Set-Location $Dir
$env:PYTHONIOENCODING = 'utf-8'

$TaskGui  = 'Obsidian-Agent Weboberflaeche'
$TaskSync = 'Obsidian-Agent Tages-Sync'
$Icon     = Join-Path $Setup 'obsidian-agent.ico'
$Daten    = Join-Path $env:LOCALAPPDATA 'Obsidian-Agent'
$LogFile  = Join-Path $Daten 'logs\gui.log'
$PyVersion = '3.12.8'

function Ok($m)   { Write-Host "[OK] $m" -ForegroundColor Green }
function Warn($m) { Write-Host "[!!] $m" -ForegroundColor Yellow }
function Info($m) { Write-Host "...  $m" }
function Fail($m) { Write-Host "[X]  $m" -ForegroundColor Red; Read-Host (T 'enter'); exit 1 }
function Lauscht($p) { [bool](Get-NetTCPConnection -LocalPort $p -State Listen -ErrorAction SilentlyContinue) }

$Host.UI.RawUI.WindowTitle = T 'titel'
Write-Host ''
Write-Host "=== $(T 'titel') ===" -ForegroundColor Cyan
Write-Host ''

# --- 1. Python -------------------------------------------------------------------
function Finde-Python {
    $kandidaten = @()
    if (Get-Command py -ErrorAction SilentlyContinue) {
        $p = & py -3 -c 'import sys; print(sys.executable)' 2>$null
        if ($p) { $kandidaten += $p.Trim() }
    }
    $c = Get-Command python -ErrorAction SilentlyContinue
    if ($c -and $c.Source -notlike '*WindowsApps*') { $kandidaten += $c.Source }
    $kandidaten += Get-ChildItem "$env:LOCALAPPDATA\Programs\Python\Python3*\python.exe", `
                                "$env:ProgramFiles\Python3*\python.exe" -ErrorAction SilentlyContinue |
                   Sort-Object FullName -Descending | ForEach-Object { $_.FullName }
    foreach ($k in $kandidaten) {
        if (-not (Test-Path $k)) { continue }
        $ok = & $k -c 'import sys; print(sys.version_info >= (3, 9))' 2>$null
        if ($ok -eq 'True') { return $k }
    }
    return $null
}

Info (T 'py_suche')
$Py = Finde-Python
if (-not $Py) {
    Info (T 'py_install')
    if (Get-Command winget -ErrorAction SilentlyContinue) {
        & winget install --id Python.Python.3.12 -e --scope user --silent --accept-package-agreements --accept-source-agreements | Out-Null
        $Py = Finde-Python
    }
    if (-not $Py) {
        $arch = if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64') { 'arm64' } else { 'amd64' }
        $url = "https://www.python.org/ftp/python/$PyVersion/python-$PyVersion-$arch.exe"
        $exe = Join-Path $env:TEMP "python-$PyVersion-$arch.exe"
        try {
            [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
            Invoke-WebRequest -Uri $url -OutFile $exe -UseBasicParsing
            Start-Process -FilePath $exe -ArgumentList '/quiet', 'InstallAllUsers=0', 'PrependPath=1', 'Include_test=0', 'Include_launcher=0' -Wait
            Remove-Item $exe -Force -ErrorAction SilentlyContinue
        } catch { Warn $_.Exception.Message }
        $Py = Finde-Python
    }
    if (-not $Py) {
        Start-Process 'https://www.python.org/downloads/windows/'
        Fail (T 'py_fehlt')
    }
}
$Pyw = Join-Path (Split-Path -Parent $Py) 'pythonw.exe'
if (-not (Test-Path $Pyw)) { $Pyw = $Py }
Ok (T 'py_ok' @("$Py ($(& $Py --version 2>&1))"))

# --- 2. Sprache, Vault, erster Sync -----------------------------------------------------
& $Py agent.py einrichten --sprache $Sprache | Out-Null
$info = (& $Py agent.py info) | ConvertFrom-Json
if (-not $info.vault_ok) {
    Info (T 'vault_hinweis')
    Add-Type -AssemblyName System.Windows.Forms
    $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
    $dlg.Description = T 'vault_frage'
    $dlg.ShowNewFolderButton = $true
    $owner = New-Object System.Windows.Forms.Form -Property @{ TopMost = $true }
    if ($dlg.ShowDialog($owner) -eq [System.Windows.Forms.DialogResult]::OK) {
        & $Py agent.py einrichten --vault $dlg.SelectedPath | Out-Null
        Ok (T 'vault_ok' @($dlg.SelectedPath))
    } else {
        Warn (T 'vault_spaeter')
    }
    $owner.Dispose()
    $info = (& $Py agent.py info) | ConvertFrom-Json
} else {
    Ok (T 'vault_ok' @($info.vault_path))
}
if ($info.vault_ok) { & $Py agent.py sync }
$Port = [int]$info.port
$SyncZeit = [string]$info.sync_zeit

# --- 3. Geplante Aufgaben ------------------------------------------------------------
$User = "$env:USERDOMAIN\$env:USERNAME"
$Settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
    -StartWhenAvailable -MultipleInstances IgnoreNew -ExecutionTimeLimit ([TimeSpan]::Zero) `
    -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1)
$Principal = New-ScheduledTaskPrincipal -UserId $User -LogonType Interactive -RunLevel Limited
$Startup = [Environment]::GetFolderPath('Startup')
$AutoLnk = Join-Path $Startup 'Obsidian-Agent.lnk'
$WS = New-Object -ComObject WScript.Shell
function Verknuepfung($pfad, $ziel, $argumente) {
    $s = $WS.CreateShortcut($pfad)
    $s.TargetPath = $ziel; $s.Arguments = $argumente; $s.WorkingDirectory = $Dir
    $s.IconLocation = $Icon; $s.Description = 'Obsidian-Agent'; $s.Save()
}
$guiArt = 'task'
try {
    $act = New-ScheduledTaskAction -Execute $Pyw -Argument "`"$Dir\hintergrund.pyw`"" -WorkingDirectory $Dir
    $trg = New-ScheduledTaskTrigger -AtLogOn -User $User
    Register-ScheduledTask -TaskName $TaskGui -Action $act -Trigger $trg -Settings $Settings `
        -Principal $Principal -Description 'Obsidian-Agent' -Force -ErrorAction Stop | Out-Null
    if (Test-Path $AutoLnk) { Remove-Item $AutoLnk -Force }
    $h, $m = $SyncZeit.Split(':')
    $act = New-ScheduledTaskAction -Execute $Pyw -Argument "`"$Dir\agent.py`" sync --geplant" -WorkingDirectory $Dir
    $trg = New-ScheduledTaskTrigger -Daily -At ([datetime]::Today.AddHours([int]$h).AddMinutes([int]$m))
    try {
        Register-ScheduledTask -TaskName $TaskSync -Action $act -Trigger $trg -Settings $Settings `
            -Principal $Principal -Description 'Obsidian-Agent' -Force -ErrorAction Stop | Out-Null
    } catch { Warn (T 'sync_fehler' @($_.Exception.Message.Trim())) }
    Ok (T 'aufgaben_ok' @($SyncZeit))
} catch {
    Verknuepfung $AutoLnk $Pyw "`"$Dir\hintergrund.pyw`""
    $guiArt = 'lnk'
    Warn (T 'aufgaben_fallback')
}

# --- 4. Verknüpfungen ---------------------------------------------------------------
$Menue = Join-Path ([Environment]::GetFolderPath('Programs')) 'Obsidian-Agent.lnk'
$Desktop = Join-Path ([Environment]::GetFolderPath('Desktop')) 'Obsidian-Agent.lnk'
Verknuepfung $Menue $Pyw "`"$Dir\starter.pyw`""
Verknuepfung $Desktop $Pyw "`"$Dir\starter.pyw`""
Ok (T 'verknuepfung')

# --- 5. Starten ----------------------------------------------------------------------
if (-not (Lauscht $Port)) {
    if ($guiArt -eq 'task') { Start-ScheduledTask -TaskName $TaskGui }
    else { Start-Process -FilePath $Pyw -ArgumentList "`"$Dir\hintergrund.pyw`"" -WorkingDirectory $Dir }
    for ($i = 0; $i -lt 30 -and -not (Lauscht $Port); $i++) { Start-Sleep -Milliseconds 500 }
}
Write-Host ''
if (Lauscht $Port) {
    Ok (T 'fertig' @($Port))
    Start-Process "http://127.0.0.1:$Port"
    Start-Sleep -Seconds 3
} else {
    Warn (T 'kein_start' @($LogFile))
    if (Test-Path $LogFile) { Get-Content $LogFile -Tail 8 }
    Read-Host (T 'enter')
}
