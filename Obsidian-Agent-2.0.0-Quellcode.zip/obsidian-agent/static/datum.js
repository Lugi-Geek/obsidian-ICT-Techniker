/* Obsidian-Agent – Datumsfelder im Format Tag/Monat/Jahr
 *
 * Native <input type="date"> zeigen das Datum im Format der Browsersprache an.
 * Dieses Skript ersetzt die Anzeige durch ein Textfeld (Tag, Monat, Jahr mit dem
 * Trennzeichen der eingestellten Sprache) mit Kalender-Button. Das originale Feld
 * bleibt unsichtbar im Formular und sendet weiterhin JJJJ-MM-TT an den Server.
 * Texte und Trennzeichen kommen aus den data-Attributen des <html>-Elements.
 */
(function () {
  const html = document.documentElement.dataset;
  const trenner = html.datumTrenner || '.';
  const pad = n => String(n).padStart(2, '0');
  const anzeige = iso => {
    const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso || '');
    return m ? [m[3], m[2], m[1]].join(trenner) : '';
  };
  function lesen(text) {
    const s = (text || '').trim();
    if (!s) return '';
    let t, mo, j;
    let m = /^(\d{1,2})[\/.\-\s](\d{1,2})[\/.\-\s](\d{2}|\d{4})$/.exec(s);
    if (m) { [, t, mo, j] = m; }
    else if ((m = /^(\d{2})(\d{2})(\d{4}|\d{2})$/.exec(s))) { [, t, mo, j] = m; }
    else if ((m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s))) { [, j, mo, t] = m; }
    else return null;
    t = +t; mo = +mo; j = +j;
    if (j < 100) j += 2000;
    const d = new Date(j, mo - 1, t);
    if (d.getFullYear() !== j || d.getMonth() !== mo - 1 || d.getDate() !== t) return null;
    return `${j}-${pad(mo)}-${pad(t)}`;
  }

  function umbauen(nativ) {
    if (nativ.dataset.ttmm) return;
    nativ.dataset.ttmm = '1';
    const feld = document.createElement('span');
    feld.className = 'datumfeld';
    const text = document.createElement('input');
    text.type = 'text';
    text.inputMode = 'numeric';
    text.placeholder = html.datumFormat || 'DD.MM.YYYY';
    text.autocomplete = 'off';
    text.value = anzeige(nativ.value);
    if (nativ.required) { text.required = true; nativ.required = false; }
    const knopf = document.createElement('button');
    knopf.type = 'button';
    knopf.className = 'datumknopf';
    knopf.title = html.kalender || '';
    knopf.textContent = '📅';
    nativ.parentNode.insertBefore(feld, nativ);
    feld.append(text, knopf, nativ);
    nativ.classList.add('datumnativ');
    nativ.tabIndex = -1;

    const pruefen = () => {
      const iso = lesen(text.value);
      if (iso === null) {
        text.setCustomValidity(html.datumFehler || '');
        return false;
      }
      text.setCustomValidity('');
      nativ.value = iso;
      return true;
    };
    text.addEventListener('input', pruefen);
    text.addEventListener('blur', () => { if (pruefen() && text.value) text.value = anzeige(nativ.value); });
    nativ.addEventListener('change', () => { text.value = anzeige(nativ.value); text.setCustomValidity(''); });
    knopf.addEventListener('click', () => {
      try { nativ.showPicker(); } catch (e) { nativ.focus(); nativ.click(); }
    });
  }

  function alle(wurzel) {
    (wurzel || document).querySelectorAll('input[type=date]').forEach(umbauen);
  }
  document.addEventListener('DOMContentLoaded', () => alle());
  document.addEventListener('submit', e => {      // vor dem Absenden: Textfelder nochmals übernehmen
    e.target.querySelectorAll('.datumfeld input[type=text]').forEach(t => t.dispatchEvent(new Event('input')));
  }, true);
  window.datumfelder = alle;
})();
