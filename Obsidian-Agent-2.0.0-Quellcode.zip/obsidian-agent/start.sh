#!/usr/bin/env bash
# Obsidian-Agent ohne Installation starten (macOS / Linux, Python 3.9+ nötig).
# Täglicher Sync ohne laufende Oberfläche (crontab -e):
#   0 4 * * *  cd /pfad/zu/obsidian-agent && python3 agent.py sync --geplant
cd "$(dirname "$0")"
exec python3 app.py
