#!/usr/bin/env python3
"""Erzeugt die Anleitungen (Markdown) aus installer/anleitung/<code>.md und den Sprachdateien.
Tabellen (Ordner, Projektstruktur, Dokumenttypen) kommen aus sprachen/<code>.py und passen so
immer zum Programm.   Aufruf: python3 anleitung_bauen.py"""
import re
import sys
from pathlib import Path

HIER = Path(__file__).resolve().parent
APP = HIER.parent / "obsidian-agent"
sys.path.insert(0, str(APP))
import sprachen  # noqa: E402
import agent  # noqa: E402

DATEI = {"de": "Anleitung_DE.md", "en": "Guide_EN.md", "fr": "Guide_FR.md",
         "it": "Guida_IT.md", "es": "Guia_ES.md", "ro": "Ghid_RO.md"}
KOPF = {  # (Ordner, Inhalt, Dokument, Dateiname)
    "de": ("Ordner", "Inhalt", "Dokument", "Dateiname"), "en": ("Folder", "Contents", "Document", "File name"),
    "fr": ("Dossier", "Contenu", "Document", "Nom de fichier"), "it": ("Cartella", "Contenuto", "Documento", "Nome file"),
    "es": ("Carpeta", "Contenido", "Documento", "Nombre de archivo"), "ro": ("Dosar", "Conținut", "Document", "Nume fișier")}
ORDNER_TEXT = {
    "projekt_ordner": {"de": "Ein Unterordner pro Projekt (Struktur siehe unten)", "en": "One subfolder per project (structure below)",
                       "fr": "Un sous-dossier par projet (structure ci-dessous)", "it": "Una sottocartella per progetto (struttura qui sotto)",
                       "es": "Una subcarpeta por proyecto (estructura abajo)", "ro": "Un subdosar pentru fiecare proiect (structura mai jos)"},
    "task_ordner": {"de": "Tasks ohne Projekt", "en": "Tasks without a project", "fr": "Tâches sans projet",
                    "it": "Attività senza progetto", "es": "Tareas sin proyecto", "ro": "Sarcini fără proiect"},
    "notiz_ordner": {"de": "Dokumente ohne Projekt", "en": "Documents without a project", "fr": "Documents sans projet",
                     "it": "Documenti senza progetto", "es": "Documentos sin proyecto", "ro": "Documente fără proiect"},
    "vorlagen_ordner": {"de": "Vorlagen, in Obsidian anpassbar", "en": "Templates, editable in Obsidian",
                        "fr": "Modèles, modifiables dans Obsidian", "it": "Modelli, modificabili in Obsidian",
                        "es": "Plantillas, editables en Obsidian", "ro": "Șabloane, editabile în Obsidian"},
    "planer_ordner": {"de": "Tagesübersicht und Archiv (automatisch)", "en": "Daily overview and archive (automatic)",
                      "fr": "Aperçu du jour et archives (automatique)", "it": "Riepilogo del giorno e archivio (automatico)",
                      "es": "Resumen del día y archivo (automático)", "ro": "Rezumatul zilei și arhiva (automat)"},
    "team_ordner": {"de": "Eine Notiz pro Teammitglied", "en": "One note per team member", "fr": "Une note par membre de l'équipe",
                    "it": "Una nota per membro del team", "es": "Una nota por miembro del equipo", "ro": "O notiță pentru fiecare membru"},
    "jourfixe_ordner": {"de": "Ein Unterordner pro Serie mit Sitzungen und Pendenzen",
                        "en": "One subfolder per series with meetings and action items",
                        "fr": "Un sous-dossier par série avec réunions et actions",
                        "it": "Una sottocartella per serie con riunioni e azioni",
                        "es": "Una subcarpeta por serie con reuniones y acciones",
                        "ro": "Un subdosar pentru fiecare serie, cu ședințe și acțiuni"},
}


def tabelle(kopf, zeilen):
    return "\n".join([f"| {kopf[0]} | {kopf[1]} |" + ("" if len(kopf) == 2 else f" {kopf[2]} |"),
                      "|" + "---|" * len(kopf)] + ["| " + " | ".join(z) + " |" for z in zeilen])


def bauen():
    ziel = APP / "Anleitung"
    ziel.mkdir(exist_ok=True)
    for code, datei in DATEI.items():
        L = sprachen.hole(code)
        k = KOPF[code]
        o = L["ordner"]
        ordner = tabelle(k[:2], [(f"`{o[x]}/`", ORDNER_TEXT[x][code]) for x in agent.ORDNER_KEYS])
        struktur = tabelle(k[:2], [(f"`{s['name']}/`", s["zweck"]) for s in L["struktur"]])
        rolle = {s["rolle"]: s["name"] for s in L["struktur"]}
        dok = []
        for typ in agent.NOTIZ_TYPEN:
            v = L["vorlagen"][typ]
            name = v["dateiname"].replace("{date}", "JJJJ-MM-TT" if code == "de" else "YYYY-MM-DD") \
                                 .replace("{monat}", "JJJJ-MM" if code == "de" else "YYYY-MM").replace("{titel_}", "…")
            dok.append((f"**{v['label']}**", f"`{rolle[agent.TYP_ROLLE[typ]]}/`", f"`{name}.md`"))
        doktypen = tabelle((k[2], k[0], k[3]), dok)
        text = (HIER / "anleitung" / f"{code}.md").read_text(encoding="utf-8")
        werte = {f"nav_{n}": L["t"][f"nav_{n}"] for n in
                 ("heute", "tasks", "projekte", "dokumentation", "vorlage", "jourfixe", "team", "suche", "einstellungen")}
        werte.update(version=agent.VERSION, ordner_tabelle=ordner, struktur_tabelle=struktur, doktypen_tabelle=doktypen,
                     praefix=L["projekt_praefix"], planer=f"{o['planer_ordner']}/{L['planer']['datei']}.md")
        andere = " · ".join(f"[{sprachen.hole(c)['name']}]({d})" for c, d in DATEI.items() if c != code)
        (ziel / datei).write_text(text.format(**werte).rstrip() + f"\n\n---\n{andere}\n", encoding="utf-8")
        print(datei)


if __name__ == "__main__":
    bauen()
