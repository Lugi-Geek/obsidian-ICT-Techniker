#!/usr/bin/env bash
# Baut den Windows-Installer (benötigt makensis, z.B. "apt install nsis" oder NSIS für Windows).
set -euo pipefail
HIER="$(cd "$(dirname "$0")" && pwd)"
APP="$HIER/../obsidian-agent"
VERSION="$(python3 -c "import re;print(re.search(r'VERSION = \"(.+?)\"', open('$APP/agent.py').read()).group(1))")"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/payload"
( cd "$APP" && tar --exclude='__pycache__' --exclude='*.pyc' --exclude='config.json' --exclude='planer.db' -cf - . ) | tar -xf - -C "$TMP/payload"
rm -f "$TMP/payload/setup/obsidian-agent.icns" "$TMP/payload/start.sh"
touch "$TMP/payload/.paket"
mkdir -p "$HIER/../dist"
makensis -V2 -DVERSION="$VERSION" -DPAYLOAD="$TMP/payload" -DOUTFILE="$HIER/../dist/Obsidian-Agent-Setup-$VERSION.exe" "$HIER/windows/Obsidian-Agent.nsi"
ls -la "$HIER/../dist"
