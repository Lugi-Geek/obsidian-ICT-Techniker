#!/usr/bin/env python3
"""
Obsidian-Agent – baut das macOS-Installationspaket (.pkg) ohne Xcode.

Das Paket ist ein "Product Archive" (xar) mit Distribution, mehrsprachigen Willkommens-/
Abschlussseiten und einem Komponentenpaket ohne Payload: Programm, Apps und Einrichtung
stecken im Scripts-Archiv; postinstall kopiert sie nach /Applications/Obsidian-Agent und
richtet den angemeldeten Benutzer ein.

Aufruf:  python3 pkgbau.py <Programmordner obsidian-agent> <Ausgabe.pkg>
Auf einem Mac geht alternativ: pkgbuild --nopayload --scripts <stage> … + productbuild.
"""
from __future__ import annotations

import gzip
import hashlib
import io
import json
import os
import re
import shutil
import stat
import struct
import sys
import tempfile
import time
import zlib
from pathlib import Path
from xml.sax.saxutils import escape

HIER = Path(__file__).resolve().parent
KENNUNG = "ch.obsidian-agent"
SPRACHEN = ["de", "en", "fr", "it", "es", "ro"]

SEITEN = {
    "de": ("Obsidian-Agent – Projektmanagement für Ihren Obsidian-Vault",
           ["Das Programm wird nach <b>/Applications/Obsidian-Agent</b> installiert.",
            "Fehlt Python, wird es automatisch von python.org installiert (Internet nötig).",
            "Danach wählen Sie Ihren Obsidian-Vault. Der Agent startet bei jeder Anmeldung im Hintergrund "
            "und aktualisiert die Tagesübersicht täglich um 04:00."],
           "Fertig! Obsidian-Agent ist installiert und öffnet sich im Browser unter "
           "<b>http://127.0.0.1:5055</b>. Später öffnen Sie ihn über <b>Programme → Obsidian-Agent</b>."),
    "en": ("Obsidian-Agent – project management for your Obsidian vault",
           ["The program is installed to <b>/Applications/Obsidian-Agent</b>.",
            "If Python is missing, it is installed automatically from python.org (internet required).",
            "Afterwards you choose your Obsidian vault. The agent starts in the background at every sign-in "
            "and refreshes the daily overview every day at 04:00."],
           "Done! Obsidian-Agent is installed and opens in your browser at <b>http://127.0.0.1:5055</b>. "
           "Later, open it via <b>Applications → Obsidian-Agent</b>."),
    "fr": ("Obsidian-Agent – gestion de projet pour votre coffre Obsidian",
           ["Le programme est installé dans <b>/Applications/Obsidian-Agent</b>.",
            "Si Python manque, il est installé automatiquement depuis python.org (connexion Internet requise).",
            "Vous choisissez ensuite votre coffre Obsidian. L'agent démarre en arrière-plan à chaque ouverture "
            "de session et actualise l'aperçu du jour chaque jour à 04:00."],
           "Terminé ! Obsidian-Agent est installé et s'ouvre dans le navigateur à l'adresse "
           "<b>http://127.0.0.1:5055</b>. Par la suite, ouvrez-le via <b>Applications → Obsidian-Agent</b>."),
    "it": ("Obsidian-Agent – gestione dei progetti per il vostro vault di Obsidian",
           ["Il programma viene installato in <b>/Applications/Obsidian-Agent</b>.",
            "Se manca Python, viene installato automaticamente da python.org (serve Internet).",
            "Poi scegliete il vostro vault di Obsidian. L'agente si avvia in background a ogni accesso e "
            "aggiorna il riepilogo del giorno ogni giorno alle 04:00."],
           "Fatto! Obsidian-Agent è installato e si apre nel browser all'indirizzo <b>http://127.0.0.1:5055</b>. "
           "In seguito apritelo da <b>Applicazioni → Obsidian-Agent</b>."),
    "es": ("Obsidian-Agent – gestión de proyectos para su bóveda de Obsidian",
           ["El programa se instala en <b>/Applications/Obsidian-Agent</b>.",
            "Si falta Python, se instala automáticamente desde python.org (se necesita Internet).",
            "Después elige su bóveda de Obsidian. El agente se inicia en segundo plano en cada inicio de sesión "
            "y actualiza el resumen del día cada día a las 04:00."],
           "¡Listo! Obsidian-Agent está instalado y se abre en el navegador en <b>http://127.0.0.1:5055</b>. "
           "Más adelante, ábralo desde <b>Aplicaciones → Obsidian-Agent</b>."),
    "ro": ("Obsidian-Agent – managementul proiectelor pentru vault-ul Obsidian",
           ["Programul este instalat în <b>/Applications/Obsidian-Agent</b>.",
            "Dacă lipsește Python, este instalat automat de pe python.org (este nevoie de internet).",
            "Apoi alegeți vault-ul Obsidian. Agentul pornește în fundal la fiecare autentificare și "
            "actualizează rezumatul zilei în fiecare zi la ora 04:00."],
           "Gata! Obsidian-Agent este instalat și se deschide în browser la <b>http://127.0.0.1:5055</b>. "
           "Ulterior îl deschideți din <b>Aplicații → Obsidian-Agent</b>."),
}
DEINST_NAME = {"de": "Obsidian-Agent deinstallieren", "en": "Uninstall Obsidian-Agent",
               "fr": "Désinstaller Obsidian-Agent", "it": "Disinstalla Obsidian-Agent",
               "es": "Desinstalar Obsidian-Agent", "ro": "Dezinstalare Obsidian-Agent"}
HTML = """<!doctype html><html><head><meta charset="utf-8"><style>
body{{font:13px -apple-system,Helvetica,sans-serif;color:#222}}h2{{font-size:15px}}li{{margin:4px 0}}
@media (prefers-color-scheme:dark){{body{{color:#eee}}}}</style></head><body>{inhalt}</body></html>"""


# ---------------------------------------------------------------------------
# cpio (odc) + gzip
# ---------------------------------------------------------------------------
def cpio_gz(wurzel: Path) -> bytes:
    roh = io.BytesIO()
    ino = 1
    eintraege = [wurzel] + sorted(wurzel.rglob("*"))
    for p in eintraege:
        rel = "." if p == wurzel else "./" + p.relative_to(wurzel).as_posix()
        st = p.lstat()
        if p.is_dir():
            modus, daten = stat.S_IFDIR | 0o755, b""
        else:
            ausfuehrbar = bool(st.st_mode & 0o111)
            modus, daten = stat.S_IFREG | (0o755 if ausfuehrbar else 0o644), p.read_bytes()
        name = rel.encode() + b"\0"
        kopf = b"070707" + b"".join(f"{v:0{n}o}".encode() for v, n in (
            (0, 6), (ino, 6), (modus, 6), (0, 6), (0, 6), (1, 6), (0, 6), (int(st.st_mtime), 11),
            (len(name), 6), (len(daten), 11)))
        roh.write(kopf + name + daten)
        ino += 1
    name = b"TRAILER!!!\0"
    roh.write(b"070707" + b"0" * 6 * 7 + b"0" * 11 + f"{len(name):06o}".encode() + b"0" * 11 + name)
    return gzip.compress(roh.getvalue(), mtime=0)


# ---------------------------------------------------------------------------
# xar
# ---------------------------------------------------------------------------
class Xar:
    def __init__(self):
        self.heap = bytearray(20)  # Platz für die TOC-Prüfsumme
        self.wurzel: list = []
        self.naechste_id = 1

    def _id(self):
        self.naechste_id += 1
        return self.naechste_id - 1

    def ordner(self, eltern: list | None, name: str) -> list:
        kinder: list = []
        (eltern if eltern is not None else self.wurzel).append(("dir", self._id(), name, kinder))
        return kinder

    def datei(self, eltern: list | None, name: str, daten: bytes, modus: int = 0o644):
        off = len(self.heap)
        self.heap += daten
        sha = hashlib.sha1(daten).hexdigest()
        (eltern if eltern is not None else self.wurzel).append(("file", self._id(), name, (off, len(daten), sha, modus)))

    def _xml(self, eintraege, tiefe=2) -> str:
        e = "  " * tiefe
        out = []
        for art, fid, name, inhalt in eintraege:
            if art == "dir":
                out.append(f'{e}<file id="{fid}"><name>{escape(name)}</name><type>directory</type>'
                           f'<mode>0755</mode><uid>0</uid><gid>0</gid><user>root</user><group>wheel</group>\n'
                           + self._xml(inhalt, tiefe + 1) + f"{e}</file>\n")
            else:
                off, groesse, sha, modus = inhalt
                out.append(
                    f'{e}<file id="{fid}"><name>{escape(name)}</name><type>file</type>'
                    f'<mode>{modus:04o}</mode><uid>0</uid><gid>0</gid><user>root</user><group>wheel</group>'
                    f'<data><offset>{off}</offset><size>{groesse}</size><length>{groesse}</length>'
                    f'<encoding style="application/octet-stream"/>'
                    f'<extracted-checksum style="sha1">{sha}</extracted-checksum>'
                    f'<archived-checksum style="sha1">{sha}</archived-checksum></data></file>\n')
        return "".join(out)

    def schreiben(self, ziel: Path):
        jetzt = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        toc = ('<?xml version="1.0" encoding="UTF-8"?>\n<xar>\n <toc>\n'
               f'  <creation-time>{jetzt}</creation-time>\n'
               '  <checksum style="sha1"><offset>0</offset><size>20</size></checksum>\n'
               + self._xml(self.wurzel) + " </toc>\n</xar>\n").encode()
        toc_z = zlib.compress(toc, 9)
        self.heap[0:20] = hashlib.sha1(toc_z).digest()
        kopf = struct.pack(">4sHHQQI", b"xar!", 28, 1, len(toc_z), len(toc), 1)
        ziel.write_bytes(kopf + toc_z + bytes(self.heap))


# ---------------------------------------------------------------------------
# Inhalt zusammenstellen
# ---------------------------------------------------------------------------
def info_plist(kennung: str, exe: str, name: str, version: str) -> str:
    lokal = "".join(f"<string>{c}</string>" for c in SPRACHEN)
    return f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleDevelopmentRegion</key><string>en</string>
<key>CFBundleExecutable</key><string>{exe}</string>
<key>CFBundleIconFile</key><string>AppIcon</string>
<key>CFBundleIdentifier</key><string>{kennung}</string>
<key>CFBundleInfoDictionaryVersion</key><string>6.0</string>
<key>CFBundleLocalizations</key><array>{lokal}</array>
<key>CFBundleName</key><string>{escape(name)}</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>CFBundleShortVersionString</key><string>{version}</string>
<key>CFBundleVersion</key><string>{version}</string>
<key>LSHasLocalizedDisplayName</key><true/>
<key>LSMinimumSystemVersion</key><string>10.15</string>
<key>NSHighResolutionCapable</key><true/>
</dict></plist>
"""


def app_bundle(ziel: Path, kennung: str, exe_name: str, exe_quelle: Path, name: str, anzeige: dict, version: str):
    c = ziel / "Contents"
    (c / "MacOS").mkdir(parents=True)
    (c / "Resources").mkdir()
    (c / "Info.plist").write_text(info_plist(kennung, exe_name, name, version))
    shutil.copy(exe_quelle, c / "MacOS" / exe_name)
    os.chmod(c / "MacOS" / exe_name, 0o755)
    shutil.copy(HIER.parent.parent / "obsidian-agent" / "setup" / "obsidian-agent.icns", c / "Resources" / "AppIcon.icns")
    for code in SPRACHEN:
        d = c / "Resources" / f"{code}.lproj"
        d.mkdir()
        (d / "InfoPlist.strings").write_text(
            f'"CFBundleDisplayName" = "{anzeige[code]}";\n"CFBundleName" = "{anzeige[code]}";\n', encoding="utf-16")


def bauen(app_quelle: Path, ausgabe: Path):
    version = re.search(r'VERSION = "(.+?)"', (app_quelle / "agent.py").read_text()).group(1)
    tmp = Path(tempfile.mkdtemp())
    try:
        skripte = tmp / "scripts"
        skripte.mkdir()
        shutil.copy(HIER / "postinstall", skripte / "postinstall")
        os.chmod(skripte / "postinstall", 0o755)
        shutil.copy(HIER / "texte.sh", skripte / "texte.sh")
        ziel = skripte / "Obsidian-Agent"
        haupt = ziel / "Obsidian-Agent.app"
        app_bundle(haupt, f"{KENNUNG}.app", "Obsidian-Agent", HIER / "launcher", "Obsidian-Agent",
                   {c: "Obsidian-Agent" for c in SPRACHEN}, version)
        shutil.copytree(app_quelle, haupt / "Contents" / "Resources" / "app",
                        ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "config.json", "planer.db",
                                                      "*.ico", "*.icns", "*.ps1", "*.bat", "*.pyc"))
        (haupt / "Contents" / "Resources" / "app" / ".paket").write_text("")
        deinst = ziel / "Uninstall Obsidian-Agent.app"
        app_bundle(deinst, f"{KENNUNG}.uninstall", "Uninstall", HIER / "uninstall", "Uninstall Obsidian-Agent",
                   DEINST_NAME, version)
        shutil.copy(HIER / "texte.sh", deinst / "Contents" / "Resources" / "texte.sh")

        x = Xar()
        dist = f"""<?xml version="1.0" encoding="utf-8"?>
<installer-gui-script minSpecVersion="2">
    <title>Obsidian-Agent {version}</title>
    <welcome file="welcome.html" mime-type="text/html"/>
    <conclusion file="conclusion.html" mime-type="text/html"/>
    <options customize="never" require-scripts="false" hostArchitectures="x86_64,arm64"/>
    <domains enable_anywhere="false" enable_currentUserHome="false" enable_localSystem="true"/>
    <volume-check><allowed-os-versions><os-version min="10.15"/></allowed-os-versions></volume-check>
    <choices-outline><line choice="default"><line choice="{KENNUNG}.pkg"/></line></choices-outline>
    <choice id="default"/>
    <choice id="{KENNUNG}.pkg" visible="false"><pkg-ref id="{KENNUNG}.pkg"/></choice>
    <pkg-ref id="{KENNUNG}.pkg" version="{version}" onConclusion="none">#agent.pkg</pkg-ref>
</installer-gui-script>
"""
        x.datei(None, "Distribution", dist.encode())
        res = x.ordner(None, "Resources")
        for code in SPRACHEN:
            titel, punkte, schluss = SEITEN[code]
            d = x.ordner(res, f"{code}.lproj")
            welcome = f"<h2>{titel}</h2><ul>" + "".join(f"<li>{p}</li>" for p in punkte) + "</ul>"
            x.datei(d, "welcome.html", HTML.format(inhalt=welcome).encode())
            x.datei(d, "conclusion.html", HTML.format(inhalt=f"<h2>Obsidian-Agent</h2><p>{schluss}</p>").encode())
        pkg = x.ordner(None, "agent.pkg")
        info = (f'<?xml version="1.0" encoding="utf-8"?>\n'
                f'<pkg-info overwrite-permissions="true" relocatable="false" identifier="{KENNUNG}.pkg" '
                f'postinstall-action="none" version="{version}" format-version="2" generator-version="obsidian-agent" '
                f'install-location="/" auth="root">\n'
                f'    <scripts>\n        <postinstall file="./postinstall"/>\n    </scripts>\n</pkg-info>\n')
        x.datei(pkg, "PackageInfo", info.encode())
        x.datei(pkg, "Scripts", cpio_gz(skripte))
        ausgabe.parent.mkdir(parents=True, exist_ok=True)
        x.schreiben(ausgabe)
        return version
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    v = bauen(Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve())
    print(json.dumps({"version": v, "pkg": sys.argv[2], "bytes": os.path.getsize(sys.argv[2])}))
