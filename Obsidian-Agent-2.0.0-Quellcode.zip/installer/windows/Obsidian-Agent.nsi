﻿; ======================================================================
;  Obsidian-Agent – Windows-Installer (NSIS 3, Unicode)
;  Installation pro Benutzer ohne Administratorrechte nach
;  %LOCALAPPDATA%\Programs\Obsidian-Agent. Danach richtet setup\setup.ps1
;  Python, Vault, Autostart und den täglichen Sync ein.
;  Bauen:  makensis -DVERSION=2.0.0 -DPAYLOAD=<Ordner> Obsidian-Agent.nsi
; ======================================================================
Unicode true
SetCompressor /SOLID lzma
!include "MUI2.nsh"

!ifndef VERSION
  !define VERSION "2.0.0"
!endif
!ifndef PAYLOAD
  !define PAYLOAD "payload"
!endif

Name "Obsidian-Agent"
!ifdef OUTFILE
  OutFile "${OUTFILE}"
!else
  OutFile "Obsidian-Agent-Setup-${VERSION}.exe"
!endif
InstallDir "$LOCALAPPDATA\Programs\Obsidian-Agent"
InstallDirRegKey HKCU "Software\Obsidian-Agent" "InstallDir"
RequestExecutionLevel user
BrandingText "Obsidian-Agent ${VERSION}"
ShowInstDetails show

VIProductVersion "${VERSION}.0"
VIAddVersionKey /LANG=0 "ProductName" "Obsidian-Agent"
VIAddVersionKey /LANG=0 "FileDescription" "Obsidian-Agent Setup"
VIAddVersionKey /LANG=0 "FileVersion" "${VERSION}"
VIAddVersionKey /LANG=0 "ProductVersion" "${VERSION}"

!define MUI_ICON "${PAYLOAD}\setup\obsidian-agent.ico"
!define MUI_UNICON "${PAYLOAD}\setup\obsidian-agent.ico"
!define MUI_ABORTWARNING
!define MUI_LANGDLL_ALLLANGUAGES
!define MUI_LANGDLL_REGISTRY_ROOT "HKCU"
!define MUI_LANGDLL_REGISTRY_KEY "Software\Obsidian-Agent"
!define MUI_LANGDLL_REGISTRY_VALUENAME "Sprache"

!define MUI_WELCOMEPAGE_TEXT "$(Willkommen)"
!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!define MUI_FINISHPAGE_TEXT "$(Fertig)"
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES

!insertmacro MUI_LANGUAGE "German"
!insertmacro MUI_LANGUAGE "English"
!insertmacro MUI_LANGUAGE "French"
!insertmacro MUI_LANGUAGE "Italian"
!insertmacro MUI_LANGUAGE "Spanish"
!insertmacro MUI_LANGUAGE "Romanian"
!insertmacro MUI_RESERVEFILE_LANGDLL

LangString SprachCode ${LANG_GERMAN} "de"
LangString Laeuft ${LANG_GERMAN} "Python, Vault und Hintergrundaufgaben werden eingerichtet …"
LangString Fertig ${LANG_GERMAN} "Obsidian-Agent ist installiert und startet ab jetzt bei jeder Anmeldung im Hintergrund.$\r$\n$\r$\nÖffnen über das Startmenü, die Desktop-Verknüpfung oder http://127.0.0.1:5055"
LangString Willkommen ${LANG_GERMAN} "Dieses Programm installiert Obsidian-Agent für das Projektmanagement in Ihrem Obsidian-Vault.$\r$\n$\r$\nEs werden keine Administratorrechte benötigt. Fehlt Python, wird es automatisch installiert."
LangString SprachCode ${LANG_ENGLISH} "en"
LangString Laeuft ${LANG_ENGLISH} "Setting up Python, vault and background tasks …"
LangString Fertig ${LANG_ENGLISH} "Obsidian-Agent is installed and now starts in the background at every sign-in.$\r$\n$\r$\nOpen it from the Start menu, the desktop shortcut or http://127.0.0.1:5055"
LangString Willkommen ${LANG_ENGLISH} "This program installs Obsidian-Agent for project management in your Obsidian vault.$\r$\n$\r$\nNo administrator rights are needed. If Python is missing, it is installed automatically."
LangString SprachCode ${LANG_FRENCH} "fr"
LangString Laeuft ${LANG_FRENCH} "Configuration de Python, du coffre et des tâches en arrière-plan …"
LangString Fertig ${LANG_FRENCH} "Obsidian-Agent est installé et démarre désormais en arrière-plan à chaque ouverture de session.$\r$\n$\r$\nOuvrez-le depuis le menu Démarrer, le raccourci du Bureau ou http://127.0.0.1:5055"
LangString Willkommen ${LANG_FRENCH} "Ce programme installe Obsidian-Agent pour la gestion de projet dans votre coffre Obsidian.$\r$\n$\r$\nAucun droit d'administrateur n'est nécessaire. Si Python manque, il est installé automatiquement."
LangString SprachCode ${LANG_ITALIAN} "it"
LangString Laeuft ${LANG_ITALIAN} "Configurazione di Python, vault e attività in background …"
LangString Fertig ${LANG_ITALIAN} "Obsidian-Agent è installato e da ora si avvia in background a ogni accesso.$\r$\n$\r$\nAprirlo dal menu Start, dal collegamento sul desktop o da http://127.0.0.1:5055"
LangString Willkommen ${LANG_ITALIAN} "Questo programma installa Obsidian-Agent per la gestione dei progetti nel vostro vault di Obsidian.$\r$\n$\r$\nNon servono diritti di amministratore. Se manca Python, viene installato automaticamente."
LangString SprachCode ${LANG_SPANISH} "es"
LangString Laeuft ${LANG_SPANISH} "Configurando Python, la bóveda y las tareas en segundo plano …"
LangString Fertig ${LANG_SPANISH} "Obsidian-Agent está instalado y a partir de ahora se inicia en segundo plano en cada inicio de sesión.$\r$\n$\r$\nÁbralo desde el menú Inicio, el acceso directo del escritorio o http://127.0.0.1:5055"
LangString Willkommen ${LANG_SPANISH} "Este programa instala Obsidian-Agent para la gestión de proyectos en su bóveda de Obsidian.$\r$\n$\r$\nNo se necesitan derechos de administrador. Si falta Python, se instala automáticamente."
LangString SprachCode ${LANG_ROMANIAN} "ro"
LangString Laeuft ${LANG_ROMANIAN} "Se configurează Python, vault-ul și activitățile din fundal …"
LangString Fertig ${LANG_ROMANIAN} "Obsidian-Agent este instalat și pornește de acum în fundal la fiecare autentificare.$\r$\n$\r$\nDeschideți-l din meniul Start, din scurtătura de pe desktop sau de la http://127.0.0.1:5055"
LangString Willkommen ${LANG_ROMANIAN} "Acest program instalează Obsidian-Agent pentru managementul proiectelor în vault-ul Obsidian.$\r$\n$\r$\nNu sunt necesare drepturi de administrator. Dacă lipsește Python, este instalat automat."

!define UNINST_KEY "Software\Microsoft\Windows\CurrentVersion\Uninstall\Obsidian-Agent"

Function .onInit
  !insertmacro MUI_LANGDLL_DISPLAY
FunctionEnd

Function un.onInit
  !insertmacro MUI_UNGETLANGUAGE
FunctionEnd

Section "Obsidian-Agent" SecMain
  SetOutPath "$INSTDIR"
  ; Bei einem Update den laufenden Agent nicht beachten: Dateien werden ersetzt,
  ; Einstellungen und Datenbank liegen getrennt in %LOCALAPPDATA%\Obsidian-Agent.
  File /r /x "__pycache__" "${PAYLOAD}\*.*"
  WriteUninstaller "$INSTDIR\Uninstall.exe"

  WriteRegStr HKCU "Software\Obsidian-Agent" "InstallDir" "$INSTDIR"
  WriteRegStr HKCU "${UNINST_KEY}" "DisplayName" "Obsidian-Agent"
  WriteRegStr HKCU "${UNINST_KEY}" "DisplayVersion" "${VERSION}"
  WriteRegStr HKCU "${UNINST_KEY}" "Publisher" "Obsidian-Agent"
  WriteRegStr HKCU "${UNINST_KEY}" "DisplayIcon" "$INSTDIR\setup\obsidian-agent.ico"
  WriteRegStr HKCU "${UNINST_KEY}" "InstallLocation" "$INSTDIR"
  WriteRegStr HKCU "${UNINST_KEY}" "UninstallString" '"$INSTDIR\Uninstall.exe"'
  WriteRegDWORD HKCU "${UNINST_KEY}" "NoModify" 1
  WriteRegDWORD HKCU "${UNINST_KEY}" "NoRepair" 1

  DetailPrint "$(Laeuft)"
  ExecWait 'powershell.exe -NoProfile -ExecutionPolicy Bypass -File "$INSTDIR\setup\setup.ps1" -Sprache $(SprachCode)' $0
SectionEnd

Section "Uninstall"
  ExecWait 'powershell.exe -NoProfile -ExecutionPolicy Bypass -File "$INSTDIR\setup\uninstall.ps1" -Sprache $(SprachCode)'
  RMDir /r "$INSTDIR"
  DeleteRegKey HKCU "${UNINST_KEY}"
  DeleteRegKey HKCU "Software\Obsidian-Agent"
SectionEnd
